'''

可以生成羊齿叶的程序
'''


from numpy import *
from random import random
from matplotlib.pyplot import *
#from matplotlib.axis import 
le = zeros([500000,2])

for i in range(1,500000) :
	x = random()
	if x<0.02 :
		le[i,0] = 0.5
		le[i,1] = 0.27*le[i-1,1]
	elif x<=0.17 :
		le[i,0] = -0.139*le[i-1,0]+0.263*le[i-1,1]+0.57
		le[i,1] = 0.246*le[i-1,0]+0.224*le[i-1,1]-0.036
	elif x<=0.3 :
		le[i,0] = 0.17*le[i-1,0]-0.215*le[i-1,1]+0.408
		le[i,1] = 0.222*le[i-1,0]+0.176*le[i-1,1]+0.0893
	else :
		le[i,0] = 0.781*le[i-1,0]+0.034*le[i-1,1]+0.1075
		le[i,1] = -0.032*le[i-1,0]+0.739*le[i-1,1]+0.27
a=le[:,0]#-2000
axes = subplot(111)
axes.plot(a,le[:,1],'g.',ms=1.0)
axis('off')
#axes.set_xticks([])
#axes.set_yticks([])
#cla()
show()
	

