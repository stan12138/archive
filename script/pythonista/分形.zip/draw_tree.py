'''
一个用于产生概率树的程序

'''
from numpy import *
from random import random
from matplotlib.pyplot import *

le = zeros([500000,2])

for i in range(1,500000) :
	x = random()
	if x<0.1 :
		le[i,0] = 0.05*le[i-1,0]
		le[i,1] = 0.6*le[i-1,1]
	elif x<=0.2 :
		le[i,0] = 0.05*le[i-1,0]
		le[i,1] = -0.5*le[i-1,1]+1.0
	elif x<=0.4 :
		le[i,0] = 0.46*le[i-1,0]-0.15*le[i-1,1]
		le[i,1] = 0.39*le[i-1,0]+0.38*le[i-1,1]+0.6
	elif x<=0.6 :
		le[i,0] = 0.47*le[i-1,0]-0.15*le[i-1,1]
		le[i,1] = 0.17*le[i-1,0]+0.42*le[i-1,1]+1.1
		#le[i,0] = 0.47*le[i-1,0]
		#le[i,1] = 0.8*le[i-1,1]+1.1
	elif x<=0.8 :
		le[i,0] = 0.43*le[i-1,0]+0.28*le[i-1,1]
		le[i,1] = -0.25*le[i-1,0]+0.45*le[i-1,1]+1.0
	else :
		le[i,0] = 0.42*le[i-1,0]+0.26*le[i-1,1]
		le[i,1] = -0.35*le[i-1,0]+0.31*le[i-1,1]+0.37
		#le[i,0] = 0.42*le[i-1,0]+0.26*le[i-1,1]
		#le[i,1] = -0.35*le[i-1,0]+0.31*le[i-1,1]+0.5


axes = subplot(111)
axes.plot(le[:,0],le[:,1],'g.',ms=1.0)
axis('off')
#axes.set_xticks([])
#axes.set_yticks([])
show()
	
