# coding: utf-8
code = {2 : ['0','1'],8:['0','1','2','3','4','5','6','7'],16:['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'],10:['0','1','2','3','4','5','6','7','8','9']}
precision = 5
'''特别注意小于零时，还未判定小数点后有东西'''
def b_to(a,b,little_than_0) :
    out_2=''
    if little_than_0 :
        if b==2 :
            out_2 = a
        elif b==8 :
            lenth = len(a)
            a = a+'0'*(3-lenth%3)
            for i in range(0,len(a),3) :
                    out_t=a[i:i+3]
                    out_t=int(out_t,2)
                    out_2=out_2+str(out_t)
        elif b==10 :
            #此处有问题
            #已修复
            out_2=0
            for i in range(len(a)) :
                out_t = int(a[i])*(2**(-(i+1)))
                out_2+=out_t
                #print('i am here')
                #print(i)
            out_2=str(out_2)
            #print('i am here')
            #print(out_2)
            out_2=out_2[out_2.index('.')+1:]
            #out_2=out_2[2:]
        elif b==16 :
            lenth = len(a)
            a = a+'0'*(4-lenth%4)
            for i in range(0,len(a),4) :
                    out_t=a[i:i+4]
                    out_t=int(out_t,2)
                    out_2=out_2+str(out_t)
    else :
        if b==2 :
            out_2 =a
        a=int(a,2)
        
        if b==8 :
            out_2=oct(a)
            out_2=out_2[2:]
        elif b==10 :
            out_2=str(a)
        elif b==16 :
            out_2=hex(a)
            out_2=out_2[2:]
    return out_2

def o_to(a,b,little_than_0) :
    out_2=''
    if little_than_0 :
        if b==2 :
            for i in a :
                out_t=int(i,8)
                out_t=bin(out_t)
                out_t=out_t[2:]
                out_2=out_2+'0'*(3-len(out_t))+out_t
        elif b==8 :
            out_2=a
        elif b==10 :
            out_2=0
            for i in range(len(a)) :
                out_t = int(a[i])*(8**(-(i+1)))
                out_2+=out_t
            out_2=str(out_2)
            out_2=out_2[out_2.index('.')+1:]
            #out_2=out_2[2:]
        elif b==16 :
            for i in a :
                out_t=int(i,8)
                out_t=bin(out_t)
                out_t=out_t[2:]
                out_2=out_2+'0'*(3-len(out_t))+out_t
            out_2=b_to(out_2,16,True)
    else :
        if b==8 :
            out_2=a
        a=int(a,8)
        if b==2 :
            out_2=bin(a)
            out_2=out_2[2:]
        
        elif b==10 :
            out_2=str(a)
        elif b==16 :
            out_2=hex(a)
            out_2=out_2[2:]
    return out_2
def t_to(a,b,little_than_0) :
    out_2=''
    if little_than_0 :
        i=0
        a='0.'+a
        a = float(a)
        while i <= precision :
            i+=1
            a=a*b
            out_t=int(a)
            a=a-out_t
            if b==2 :
                out_t=bin(out_t)
                out_t=out_t[2:]
            elif b==8 :
                out_t=oct(out_t)
                out_t=out_t[2:]
            elif b==10 :
                out_t=str(out_t)
            elif b==16 :
                out_t=hex(out_t)
                out_t=out_t[2:]
            out_2 = out_2 + out_t
    else :
        a=int(a,10)
        if b==2 :
            out_2=bin(a)
            out_2=out_2[2:]
        elif b==8 :
            out_2=oct(a)
            out_2=out_2[2:]
        elif b==10 :
            out_2=str(a)
        elif b==16 :
            out_2=hex(a)
            out_2=out_2[2:]
    return out_2

def h_to(a,b,little_than_0) :
    out_2=''
    if little_than_0 :
        if b==2 :
            for i in a :
                out_t=int(i,16)
                out_t=bin(out_t)
                out_t=out_t[1:]
                out_2=out_2+'0'*(4-len(out_t))+out_t
        elif b==8 :
            for i in a :
                out_t=int(i,16)
                out_t=bin(out_t)
                out_t=out_t[2:]
                out_2=out_2+'0'*(4-len(out_t))+out_t
            
            out_2=b_to(out_2,8,True)
        elif b==10 :
            out_2=0
            for i in range(len(a)) :
                out_t = int(a[i])*(16**(-(i+1)))
                out_2+=out_t
            out_2=str(out_2)
            out_2=out_2[out_2.index('.')+1:]
            #out_2=out_2[2:]
        elif b==16 :
            out_2=a
    else :
        if b==16 :
            out_2=a
        a=int(a,16)
        if b==2 :
            out_2=bin(a)
            out_2=out_2[2:]
        
        elif b==10 :
            out_2=str(a)
        elif b==8 :
            out_2=oct(a)
            out_2=out_2[2:]
            #print('i am here')
            #print(a)
    return out_2
        
 
                
                
def translate(a,b,c) :
    l=len(a)
    po=0
    ne_flage=False
    wrong_flage = False
    fnum=''
    inum=''
    
    if '.' in a:
        po=a.index('.')
        fnum=a[po+1:]
        if '-'  in a :
            ne_flage=True
            inum=a[1:po]
        else :
            inum=a[0:po]
    else :
        if '-' in a :
            ne_flage = True
            inum=a[1:]
        else :
            inum=a[0:]
    for i in inum :
        if i in code[b] :
            pass
        else :
            wrong_flage = True
            break
    for i in fnum :
        if i in code[b] :
            pass
        else :
            wrong_flage = True
            break
    if not wrong_flage :
        out_2=''
        if b==2 :
            out1=b_to(inum,c,False)
            if len(fnum) > 0 :
                out_2=b_to(fnum,c,True)
        elif b==8 :
            out1=o_to(inum,c,False)
            if len(fnum) >0 :
                out_2=o_to(fnum,c,True)
        elif b==10 :
            out1=t_to(inum,c,False)
            if len(fnum) >0 :
                out_2=t_to(fnum,c,True)
        elif b==16 :
            #print('now i am here')
            out1=h_to(inum,c,False)
            if len(fnum) >0 :
                out_2=h_to(fnum,c,True)
        if len(out_2)>0 :
            out=out1+'.'+out_2
        else :
            out=out1
        #print('this is result')
        #print(out)
        return out
    else :
        #print('wrong!')
        return 'wrong input'

    #print('this is wrong')
    #print(wrong_flage)
    '''print('this is inum')
    print(inum) 
    print('this is fnum')      
    print(fnum)
    print('this is result')
    print(out)'''
    
if __name__=='__main__' :
    a='0.01011'
    print('this is origin number')
    print(a)
    print(translate(a,2,8))
    #print(code[16])
'''
16.5.31
作者:Stan
测试通过
'''  
        
        
  
