# coding: utf-8

import ui
from Mark_core import translate
origin_flage=10
ambition_flage=10

str1=''
biggest_lenth = 16
str2='ABCDEF'
str3='abcdef'
'''此处做了一个示例，关于如何调用使用pyui设计的ui中的元件'''
def tap_num(sender) :
    global str1
    v['label1'].text='I am here'
    if len(str1) < biggest_lenth :
        if sender.title in str2 :
            a=str3[str2.index(sender.title)]
        else :
            a=sender.title
        str1=str1+a
        v['label2'].text=str1
    #print(sender.title)
def tap_point(sender) :
    global str1
    if len(str1) < biggest_lenth :
        str1=str1+sender.title
        v['label2'].text=str1
    #print(sender.title)
def tap_equal(sender) :
    global str1
    v['label1'].text=str1+' ='
    v['label2'].text=translate(str1,origin_flage,ambition_flage)
    str1=''
def tap_delet(sender) :
    global str1
    str1=str1[0:-1]
    v['label2'].text=str1
    #print(sender.title)
def b_to_o(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 2
    ambition_flage = 8
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='#ff86ff'
    
    #print(sender.title)
def b_to_t(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 2
    ambition_flage = 10
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='#ff86ff'
    #print(sender.title)
def b_to_h(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 2
    ambition_flage = 16
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='#ff86ff'
    #print(sender.title)
def o_to_b(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 8
    ambition_flage = 2
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='#ff86ff'
    #print(sender.title)
def o_to_t(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 8
    ambition_flage = 10
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='#ff86ff'
    #print(sender.title)
def o_to_h(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 8
    ambition_flage = 16
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='#ff86ff'
    #print(sender.title)
def t_to_b(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 10
    ambition_flage = 2
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='#ff86ff'
    #print(sender.title)
def t_to_o(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 10
    ambition_flage = 8
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='blue'
    #print(sender.title)
def t_to_h(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 10
    ambition_flage = 16
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='blue'
    #print(sender.title)
def h_to_b(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 16
    ambition_flage = 2
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='blue'
    #print(sender.title)
def h_to_o(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 16
    ambition_flage = 8
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='blue'
    #print(sender.title)
def h_to_t(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 16
    ambition_flage = 10
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='blue'
    #print(sender.title)
v=ui.load_view('Mark_1')

b=v.subviews

v2=b[2:30]
func=b[30:33]
for i in func :
    i.border_color='#dfdfdf'
    i.border_width=1
    i.frame=(func.index(i)*110+5,432,90,42)

#print(len(func))
for i in v2 :
    i.border_color='#dfdfdf'
    i.border_width=1
list=range(0,len(v2),4)

for i in list :
    v2[i].frame=(5,118+list.index(i)*45,70,42)
    v2[i+1].frame=(85,118+list.index(i)*45,70,42)
    v2[i+2].frame=(165,118+list.index(i)*45,70,42)
    v2[i+3].frame=(245,118+list.index(i)*45,70,42)
    
list=v2[16:]
v.present('sheet')

'''v = ui.load_view('Translate')
b=v.subviews
for i in range(len(v.subviews)) :
    print(b[i].title)
#print(len(v.subviews))
#v.frame=(100,100,100,100)
#v['stan'].bg_color='#360cff'
#v['stan'].frame=(40,50,50,10)
v.present('sheet')'''

'''v1=v['view1']
v1.add_subview(v['button1'])
a=v1.subviews[0]
a.bg_color='#ff0cca'
print(len(v1.subviews))
v.present('sheet')'''

#for i in range(len(v2)) :
#    print(v2[i].title)
#print(len(v2))