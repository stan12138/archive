# coding: utf-8

import ui
from Mark_core import translate
origin_flage=16
ambition_flage=10
chose_color = '#a1ffa1'
str1=''
biggest_lenth = 16
str2='ABCDEF'
str3='abcdef'
def tap_num(sender) :
    global str1
    v['label1'].text='I am here'
    if len(str1) < biggest_lenth :
        if sender.title in str2 :
            a=str3[str2.index(sender.title)]
        else :
            a=sender.title
        str1=str1+a
        v['label2'].text=str1
    #print(sender.title)
def tap_point(sender) :
    global str1
    if len(str1) < biggest_lenth :
        str1=str1+sender.title
        v['label2'].text=str1
    #print(sender.title)
def tap_equal(sender) :
    global str1
    v['label1'].text=str1+' ='
    v['label2'].text=translate(str1,origin_flage,ambition_flage)
    str1=''
def tap_delet(sender) :
    global str1
    str1=str1[0:-1]
    v['label2'].text=str1
    #print(sender.title)
def tap_ac(sender) :
	global str1
	str1=''
	v['label2'].text=str1

def from_numbers(sender) :
	global origin_flage
	for i in range(origin_flage,len(numbers)) :
		v.add_subview(numbers[i])
	#v['label1'].text=sender.title
	
	origin_flage=int(sender.title)
	for i in range(origin_flage,len(numbers)) :
		v.remove_subview(numbers[i])
	for i in from_num :
		i.bg_color = 'clear'
	if origin_flage==2 :
		from_num[0].bg_color= chose_color
		numbers[0].frame=(	5,276,150,180)
		numbers[1].frame=(	165,276,150,180)
	elif origin_flage==8 :
		from_num[1].bg_color=chose_color
		for i in range(4) :
			numbers[i].frame=(5+80*i,276,70,84)
			numbers[i+4].frame=(5+80*i,370,70,84)
	elif origin_flage==10 :
		from_num[2].bg_color=chose_color
		for i in range(5) :
			numbers[i].frame=(5+63*i,276,60,84)
			numbers[i+5].frame=(5+63*i,370,60,84)
	elif origin_flage==16 :
		from_num[3].bg_color=chose_color
		list = range(0,len(numbers),4)
		for i in list :
		  numbers[i].frame=(5,276+list.index(i)*45,70,42)
		  numbers[i+1].frame=(85,276+list.index(i)*45,70,42)
		  numbers[i+2].frame=(165,276+list.index(i)*45,70,42)
		  numbers[i+3].frame=(245,276+list.index(i)*45,70,42)
def to_numbers(sender) :
	global ambition_flage
	#v['label2'].text=sender.title
	ambition_flage = int(sender.title)
	for i in to_num :
		i.bg_color = 'clear'
	for i in to_num :
		if i.title == sender.title :
			i.bg_color = chose_color
		
	
v=ui.load_view('Mark_2')

b=v.subviews
func=b[2:6]
from_num=b[7:11]
to_num=b[12:16]
numbers=b[16:-1]
all_key=func+from_num+to_num+numbers
for i in all_key :
	i.border_color='#d7d7d7'
	i.border_width=2
list = range(0,len(numbers),4)
for i in list :
    numbers[i].frame=(5,276+list.index(i)*45,70,42)
    numbers[i+1].frame=(85,276+list.index(i)*45,70,42)
    numbers[i+2].frame=(165,276+list.index(i)*45,70,42)
    numbers[i+3].frame=(245,276+list.index(i)*45,70,42)
    	

v.present('sheet')


'''numbers=b[2:18]
#this is the list of all numbers
v2=numbers
func=b[30:33]
func=func+(b[35],)
#此处获得了四个功能键的列表
for i in func :
    i.border_color='#dfdfdf'
    i.border_width=1
    i.frame=(func.index(i)*80+5,432,70,42)
#all_de=b[35]
#print(all_de.title)
#all_de.bgcolor='red'
#all_de.frame=(100,100,70,42)
#print(len(func))
for i in v2 :
    i.border_color='#dfdfdf'
    i.border_width=1
list=range(0,len(numbers),4)
#print()
for i in list :
    v2[i].frame=(5,118+list.index(i)*45,70,42)
    v2[i+1].frame=(85,118+list.index(i)*45,70,42)
    v2[i+2].frame=(165,118+list.index(i)*45,70,42)
    v2[i+3].frame=(245,118+list.index(i)*45,70,42)
    
list=v2[16:]'''
'''v = ui.load_view('Translate')
b=v.subviews
for i in range(len(v.subviews)) :
    print(b[i].title)
#print(len(v.subviews))
#v.frame=(100,100,100,100)
#v['stan'].bg_color='#360cff'
#v['stan'].frame=(40,50,50,10)
v.present('sheet')'''

'''v1=v['view1']
v1.add_subview(v['button1'])
a=v1.subviews[0]
a.bg_color='#ff0cca'
print(len(v1.subviews))
v.present('sheet')'''

#for i in range(len(v2)) :
#    print(v2[i].title)
#print(len(v2))
'''
def b_to_o(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 2
    ambition_flage = 8
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='#ff86ff'
    
    #print(sender.title)
def b_to_t(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 2
    ambition_flage = 10
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='#ff86ff'
    #print(sender.title)
def b_to_h(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 2
    ambition_flage = 16
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='#ff86ff'
    #print(sender.title)
def o_to_b(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 8
    ambition_flage = 2
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='#ff86ff'
    #print(sender.title)
def o_to_t(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 8
    ambition_flage = 10
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='#ff86ff'
    #print(sender.title)
def o_to_h(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 8
    ambition_flage = 16
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='#ff86ff'
    #print(sender.title)
def t_to_b(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 10
    ambition_flage = 2
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='#ff86ff'
    #print(sender.title)
def t_to_o(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 10
    ambition_flage = 8
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='blue'
    #print(sender.title)
def t_to_h(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 10
    ambition_flage = 16
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='blue'
    #print(sender.title)
def h_to_b(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 16
    ambition_flage = 2
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='blue'
    #print(sender.title)
def h_to_o(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 16
    ambition_flage = 8
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='blue'
    #print(sender.title)
def h_to_t(sender) :
    global origin_flage
    global ambition_flage
    origin_flage = 16
    ambition_flage = 10
    for i in list :
        i.bg_color='clear' 
    sender.bg_color='blue'
    #print(sender.title)'''
