# coding: utf-8
'''这是一个演示普通碰撞的程序'''
from Ve import *
from General_hit_test import *
from scene import *

ball = Texture('emj:Blue_Circle')
font = ('Anonymous Pro',30)

class Ball :
	def __init__(self,parent1,position,ball=Texture('emj:Blue_Circle'),v=vec(1,-1),m=10,r=57.7/2) :
		self.name = SpriteNode(ball,parent = parent1)
		self.v = v
		self.m = m
		self.r = r
		self.posx,self.posy = position
		self.name.position = position
		
	def move(self) :
		self.posx += self.v.name[0]
		self.posy += self.v.name[1]
		self.name.position = (self.posx,self.posy)
		
class My(Scene) :
	def setup(self) :
		self.background_color = '#9d51ff'
		
		self.ball = []
		
		self.txt = LabelNode('I am here',font,parent=self)
		self.txt.position = (self.size.w/2,self.size.h-100)
		self.txt2 = LabelNode('I am here',font,parent=self)
		self.txt2.position = (self.size.w/2,self.size.h-150)
		self.txt3 = LabelNode('I am here',font,parent=self)
		self.txt3.position = (self.size.w/2,self.size.h-200)
		
	def update(self) :
		self.txt.text = str(len(self.ball))
		gx,gy,gz = gravity()
		self.txt3.text = 'x: '+'%.2f'%gx+' '+'y: '+'%.2f'%gy
		self.e = 0
		if len(self.ball) >=2 :
			for i in range(len(self.ball)) :
				self.e +=0.5*self.ball[i].m*self.ball[i].v.lenth**2
				for j in range(i+1,len(self.ball)):
					check(self.ball,self.size.w,self.size.h)
		else :
			for i in range(len(self.ball)) :
				wall(self.ball[i],self.size.w,self.size.h)
		self.txt2.text = 'Energy : '+'%.2f'%self.e
		for i in self.ball :
			i.move()
			
	def touch_began(self,touch) :
	
		x,y = touch.location
		x1,y1,z1 = gravity()
		'''if x<100 and y<100 :
		self.ball.append(Ball(self,(self.size.w/2,self.size.h/2+200),v=vec(0,-8),m=10))
		self.ball.append(Ball(self,(self.size.w/2,self.size.h/2),v=vec(0,0),m=10))
		self.ball.append(Ball(self,(self.size.w/2,self.size.h/2-57.7-3),v=vec(0,0),m=10))
		self.ball.append(Ball(self,(self.size.w/2,self.size.h/2-(57.7-3)*2),v=vec(0,0),m=10))
		self.ball.append(Ball(self,(self.size.w/2,self.size.h/2-(57.7-3)*3),v=vec(0,0),m=10))
		else :
		pass'''
		
		self.ball.append(Ball(self,(x,y),v=vec(10*x1,10*y1)))
		#if len(self.ball)<5:
			#self.ball[-1].v=vec(0,0)
			
run(My(),PORTRAIT,show_fps = True)

