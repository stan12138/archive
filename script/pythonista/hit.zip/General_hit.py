# coding: utf-8
from Ve import *
from math import *
#from scene import *
'''16.5.15特别提醒，此程序依旧有bug，1，碰撞甄别只改正了x轴，y轴还没改，2，碰撞速度分解处理时y轴的公式似乎用错了，y轴好像应该保持不变，3，关于自动形成一定间隔的问题我认为应该可以修正'''
'''16.5.15晚，特别提醒，现在的函数在处理多球碰撞时会发生错误，能量不再守恒。至少目前推测原因是这样的
16.5.17,这个不是最新版，最新版在General_hit_test,去看那个吧，这个是一个旧的废弃的版本'''
def modify_something2(a,b) :
	#16.5.12此函数的编写目的在于修正碰撞卡死的问题，方式是预测下一帧，检测下一帧的情况
	apos = vec(a.posx,a.posy)
	bpos = vec(b.posx,b.posy)
	apos = apos+a.v
	bpos = bpos+b.v
	if sqrt((a.posx-b.posx)**2+(a.posy-b.posy)**2) <=57.7 :
		return 1
	elif sqrt((apos.name[0]-bpos.name[0])**2+(apos.name[1]-bpos.name[1])**2) <=54.9 :
		return 2
	else :
		return False
		
		
class Ball1 :
	def __init__(self,position,v=vec(1,-1),m=10,r=57.7/2) :
	
		self.v = v
		self.m = m
		self.r = r
		self.posx,self.posy = position
		
	def move(self) :
		self.posx += self.v.name[0]
		self.posy += self.v.name[1]
		self.name.position = (self.posx,self.posy)
		
def hit(a,b) :
	rx = vec(b.posx-a.posx,b.posy-a.posy)
	rx = vec(1,rx.angel,location = False)
	ry = vec(-rx.name[1],rx.name[0])
	vax = a.v*rx
	vay = a.v*ry
	vbx = b.v*rx
	vby = b.v*ry
	last=sqrt((a.posx-b.posx)**2+(a.posy-b.posy)**2)
	apos = vec(a.posx,a.posy)
	bpos = vec(b.posx,b.posy)
	apos = apos+a.v
	bpos = bpos+b.v
	if sqrt((apos.name[0]-bpos.name[0])**2+(apos.name[1]-bpos.name[1])**2) <last :
		va1 = rx*(vax*(a.m-b.m)/(a.m+b.m)+vbx*2*b.m/(a.m+b.m))
		vb1 = rx*(vbx*(b.m-a.m)/(a.m+b.m)+vax*2*a.m/(a.m+b.m))
	else :
		va1=rx*vax
		vb1=rx*vbx
	#va2 = ry*(vay*(a.m-b.m)/(a.m+b.m)+vby*2*b.m/(a.m+b.m))
	#vb2 = ry*(vby*(b.m-a.m)/(a.m+b.m)+vay*2*a.m/(a.m+b.m))
	va2=ry*vay
	vb2=ry*vby
	
	a.v = va1+va2
	b.v = vb1+vb2
def wall(a,wi,he) :
	if a.posx<=57.7/2 :
		a.v = vec(abs(a.v.name[0]),a.v.name[1])
	if a.posy<=57.7/2 :
		a.v = vec(a.v.name[0],abs(a.v.name[1]))
	if a.posx>=wi-57.7/2 :
		a.v=vec(-abs(a.v.name[0]),a.v.name[1])
	if a.posy>=he-57.7/2 :
		a.v = vec(a.v.name[0],-abs(a.v.name[1]))
def check(a,b,wi,he) :
	wall(a,wi,he)
	wall(b,wi,he)
	
	if modify_something2(a,b)==1 :
	
		hit(a,b)
	elif modify_something2(a,b)==2 :
		hit(a,b)
if __name__ == '__main__' :
	a=Ball1((100,100),v=vec(0,8))
	b=Ball1((100,155),v=vec(0,0))
	print('a')
	print(a.v)
	print('b')
	print(b.v)
	hit(a,b)
	print('a')
	print(a.v)
	print('b')
	print(b.v)

