# coding: utf-8
from Ve import *
from math import *
#from scene import *
'''16.5.15特别提醒，此程序依旧有bug，1，碰撞甄别只改正了x轴，y轴还没改，2，碰撞速度分解处理时y轴的公式似乎用错了，y轴好像应该保持不变，3，关于自动形成一定间隔的问题我认为应该可以修正'''
'''16.5.15晚，特别提醒，现在的函数在处理多球碰撞时会发生错误，能量不再守恒。至少目前推测原因是这样的'''
'''2016.5.17,I quit,现在的程序可以工作了，然而，又告诉我说，使用的物理规律不对，我感觉很受挫，竟然在碰撞的物理规律上出错，我竟然找不出正确的做法，我不干了，至少最近放弃了。在此之前，最后声明一下当前程序使用的规律和疑问:
1，碰墙之后会根据碰墙的具体情况让速度的一个方向的分量反向。
2，在一个链状或成堆的球中程序会在一帧中完成完整的能量传递，从头传到尾
3，完全弹性碰撞
4，当一个球同时碰撞多个球时，会把碰撞过程分解为，球以原速度与每个球分别碰撞，然后根据碰撞前这数个球的速度向量的合成，等于碰撞之后的速度向量的合成。
5，当一个球同时被多个球碰撞时，首先将会使每次碰撞都不直接改变该球的速度，而是记录下来，会在所有碰撞完成之后，将每次碰撞后的速度合成形成最终速度。
6，疑问1:A,B,C三球呈等边三角形排列，A球具有一个朝向B球的速度，那么请问，碰撞时A与C球会有能量交换吗？
7，疑问2:现在的程序对于一碰多采用的处理方法是4，这样真的是对的吗？
8，特别声明，现在的程序只能针对特定的球的那个Texture处理，直径57.7的那个，无法处理其它的。'''
'''sorry,顿时发现了很多问题，普通的碰撞处理效率极低，6个球足以使程序卡死，链状的，恶意使球重复排列，能量严重增加,莫名其妙'''
def judge_hit_or_not(ball,i,j) :
	#16.5.12此函数的编写目的在于修正碰撞卡死的问题，方式是预测下一帧，检测下一帧的情况
	a=ball[i]
	b=ball[j]
	apos = vec(a.posx,a.posy)
	bpos = vec(b.posx,b.posy)
	apos = apos+a.v
	bpos = bpos+b.v
	flage = 0
	
	if sqrt((a.posx-b.posx)**2+(a.posy-b.posy)**2) <=57.75 :#and not j==5:
		pass
	elif sqrt((apos.name[0]-bpos.name[0])**2+(apos.name[1]-bpos.name[1])**2) <=54.9 :#and not j==5:
		pass
	else :
		return False
		
	last=sqrt((a.posx-b.posx)**2+(a.posy-b.posy)**2)
	apos = vec(a.posx,a.posy)
	bpos = vec(b.posx,b.posy)
	apos = apos+a.v
	bpos = bpos+b.v
	
	if sqrt((apos.name[0]-bpos.name[0])**2+(apos.name[1]-bpos.name[1])**2) <=last :
		return True
	else :
		return False
		
class Ball1 :
	def __init__(self,position,v=vec(1,-1),m=10,r=57.7/2) :
	
		self.v = v
		self.m = m
		self.r = r
		self.posx,self.posy = position
		
	def move(self) :
		self.posx += self.v.name[0]
		self.posy += self.v.name[1]
		self.name.position = (self.posx,self.posy)
#这是一个测试类

def hit(a,b,notsametime=True) :
	rx = vec(b.posx-a.posx,b.posy-a.posy)
	rx = vec(1,rx.angel,location = False)
	ry = vec(-rx.name[1],rx.name[0])
	vax = a.v*rx
	vay = a.v*ry
	vbx = b.v*rx
	vby = b.v*ry
	
	va1 = rx*(vax*(a.m-b.m)/(a.m+b.m)+vbx*2*b.m/(a.m+b.m))
	vb1 = rx*(vbx*(b.m-a.m)/(a.m+b.m)+vax*2*a.m/(a.m+b.m))
	va2=ry*vay
	vb2=ry*vby
	if notsametime :
		a.v = va1+va2
		b.v = vb1+vb2
	else :
		a.v = va1+va2
		return vb1+vb2
		
def wall(a,wi,he) :
	if a.posx<=57.7/2 :
		a.v = vec(abs(a.v.name[0]),a.v.name[1])
	if a.posy<=57.7/2 :
		a.v = vec(a.v.name[0],abs(a.v.name[1]))
	if a.posx>=wi-57.7/2 :
		a.v=vec(-abs(a.v.name[0]),a.v.name[1])
	if a.posy>=he-57.7/2 :
		a.v = vec(a.v.name[0],-abs(a.v.name[1]))
		
#下面是一个曾经使用的旧的check函数
'''def check(ball,wi,he,t) :
    for i in ball :
        wall(i,wi,he)
    recordhit=1
    while recordhit>0 :
        recordhit=0
        for i in range(len(ball)) :
            if ball[i].v.lenth >0.001 :
                list=[]
                list1=range(len(ball))
                list1.remove(i)'''
                #if i==3 :
                    #print('this is 333333333')

                #for j in list1 :
                    #if i==3 and j==5 :
                        #print('oh oh oh oh oh oh oh oh oh oh')
                    #if judge_hit_or_not(ball,i,j) :
                        #list.append(j)
                #print('this is %s time,and the %s ball'%(t,i))
                #print(list)
'''                recordhit+=len(list)
                if len(list) == 1 :
                    hit(ball[i],ball[list[0]])
                elif len(list) >1 :
                    record=ball[i].v
                    for j in list :
                        ball[i].v=record
                        hit(ball[i],ball[j])
                    ball[i].v=record
                    record=vec(0,0)
                    for j in list :
                        record=record+ball[j].v
                    ball[i].v=ball[i].v-record
                #print(ball[i].v)
    #print(t)
    #print(ball[2].v)
    #print(ball[3].v)'''
'''陈述检测逻辑


'''
def check(ball,wi,he,t=0) :
	list_all_hit=[1]#记录接下来会被撞击的所有的球的编号
	same_time =[]#记录会被一个以上的球同时撞击的球的编号
	list_can_hit=[]
	for i in ball :
		wall(i,wi,he)
	recordhit=1#
	while_time=0
	while recordhit>0 and while_time<20 :
		while_time+=1
		recordhit=0
		#lanqibazao=0
		list_all_hit=[]
		list_can_hit=[]
		same_time =[]
		same_time_vec=[]#用于同步记录这些会被多次撞击的球，每次撞击获得的速度向量
		#筛选纪录接下来的撞击情况
		q=True
		for i in range(len(ball)) :
			for p in range(len(list_all_hit)) :
				if i in list_all_hit[p] :
					q=False
					break
			#首先认为只有速度大于一定界限的球在接下来才回主动撞击其它的球
			if ball[i].v.lenth>0.001 and q  :
			
				list_x=[]#如果速度筛选通过，建一个空表，存储这颗球的撞击目标
				list1=list(range(len(ball)))
				
				list1.remove(i)   #建立一个包含了除当前球之外，所有球的列表
				for j in list1 :
					if judge_hit_or_not(ball,i,j) :
						list_x.append(j)
				#经过一次遍历，获得了当前球的撞击目标列表
				if len(list_x)>0 :
					list_can_hit.append(i)
					list_all_hit.append(list_x)#将列表存入总的撞击列表末端
					recordhit+=len(list_x)
		#经过对所有球的循环，找到所有将被撞击的目标
		#开始统计有哪些球会被一个以上的球同时撞击
		for number in range(len(ball)) :
			num = 0
			for i in list_all_hit :
				if number in i :
					num+=1
			if num > 1 :
				same_time.append(number)
		num=0
		for i in same_time :
			same_time_vec.append([])#将速度向量的存储列表扩大至与被多次撞击的球数目相同
		#开始执行撞击
		for i in list_can_hit :
			all_my_goal = vec(0,0)
			if ball[i].v.lenth >0.05 :
				list_xx=list_all_hit[num]#如果当前球的速度过了界限，那么在总撞击列表中一定有一个属于它的撞击目标列表,挑选出属于它的列表，同时让位置标记后移一位
				num+=1
				#如果这颗球的撞击目标列表长度大于零，说明它有撞击目标
				if len(list_xx) >0 :
					record=ball[i].v #要保证对它的每一个目标都以原速度撞击，必须记录原速度向量
					#从目标列表内选择对象，开始撞击
					for j in list_xx :
						all_my_goal+=ball[j].v
						ball[i].v=record#撞击速度置为原速度
						#如果撞击的目标会被多次撞击,执行不直接传递速度的撞击
						if j in same_time :
							bbb=hit(ball[i],ball[j],notsametime=False)#把被撞击目标最后将会获得的速度返回
							same_time_vec[same_time.index(j)].append(bbb)
							#存入速度存储列表中这颗被撞击球所拥有的列表中
						else :
							hit(ball[i],ball[j])
							#如果这颗球并不是一颗会被多次撞击的球，那么执行普通的碰撞，直接传递速度
					ball[i].v=record#球速恢复原状
					record=vec(0,0)
					#合成它的所有目标球的速度
					for j in list_xx :
						#如果这是一颗会被多次撞击的球，那么，它获得的速度存储在速度向量存储列表的属于它的位置的小列表的最后一个
						if j in same_time :
							record+=same_time_vec[same_time.index(j)][-1]
						else :
							record=record+ball[j].v
					ball[i].v=ball[i].v+all_my_goal-record
					#这颗球的速度等于从被撞球中损失的速度的剩余值
		for i in same_time :
			for j in same_time_vec[same_time.index(i)] :
				ball[i].v+=j
				
if __name__ == '__main__' :
	a=Ball1((100,100),v=vec(-1,-sqrt(3)))
	b=Ball1((100+57.7/2,100-57.7*sqrt(3)/2),v=vec(0,0))
	c=Ball1((100-57.7/2,100-57.7*sqrt(3)/2),v=vec(0,0))
	ba=[a,b,c]
	print('a')
	print(a.v)
	print('b')
	print(b.v)
	print('c')
	print(c.v)
	print(judge_hit_or_not(ba,0,2))
	print('a')
	print(a.v)
	print('b')
	print(b.v)
	print('c')
	print(c.v)
'''备注一:当两个球斜碰时似乎会造成能量的大幅增加'''

