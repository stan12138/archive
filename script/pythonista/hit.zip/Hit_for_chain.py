# coding: utf-8
from Ve import *
from math import *
#from scene import *
'''16.5.15特别提醒，此程序依旧有bug，1，碰撞甄别只改正了x轴，y轴还没改，2，碰撞速度分解处理时y轴的公式似乎用错了，y轴好像应该保持不变，3，关于自动形成一定间隔的问题我认为应该可以修正'''
def modify_something2(a,b) :
    #16.5.12此函数的编写目的在于修正碰撞卡死的问题，方式是预测下一帧，检测下一帧的情况
    apos = vec(a.posx,a.posy)
    bpos = vec(b.posx,b.posy)
    apos = apos+a.v
    bpos = bpos+b.v
    if sqrt((a.posx-b.posx)**2+(a.posy-b.posy)**2) <=57.7 :
        return 1
    elif sqrt((apos.name[0]-bpos.name[0])**2+(apos.name[1]-bpos.name[1])**2) <=54.9 :
        return 2
    else :
        return False
        
 
class Ball1 :
    def __init__(self,position,v=vec(1,-1),m=10,r=57.7/2) :
        
        self.v = v
        self.m = m
        self.r = r
        self.posx,self.posy = position
        
    def move(self) :
        self.posx += self.v.name[0]
        self.posy += self.v.name[1]
        self.name.position = (self.posx,self.posy)
       
def hit(a,b) :
    rx = vec(b.posx-a.posx,b.posy-a.posy)
    rx = vec(1,rx.angel,location = False)
    ry = vec(-rx.name[1],rx.name[0])
    vax = a.v*rx
    vay = a.v*ry
    vbx = b.v*rx
    vby = b.v*ry
    last=sqrt((a.posx-b.posx)**2+(a.posy-b.posy)**2)
    apos = vec(a.posx,a.posy)
    bpos = vec(b.posx,b.posy)
    apos = apos+a.v
    bpos = bpos+b.v
    if sqrt((apos.name[0]-bpos.name[0])**2+(apos.name[1]-bpos.name[1])**2) <last :
        va1 = rx*(vax*(a.m-b.m)/(a.m+b.m)+vbx*2*b.m/(a.m+b.m))
        vb1 = rx*(vbx*(b.m-a.m)/(a.m+b.m)+vax*2*a.m/(a.m+b.m))
    else :
        va1=rx*vax
        vb1=rx*vbx
    #va2 = ry*(vay*(a.m-b.m)/(a.m+b.m)+vby*2*b.m/(a.m+b.m))
    #vb2 = ry*(vby*(b.m-a.m)/(a.m+b.m)+vay*2*a.m/(a.m+b.m))
    va2=ry*vay
    vb2=ry*vby
    a.v = va1+va2
    b.v = vb1+vb2
#修改之后的hit函数会自动识别能量的传递，可以克服由于两球接触而错误传递的情况，总而言之，可以给予该函数足够的信任，它可以完美的处理正碰，斜碰，以及识别接触虽然已经发生，但是否应该进行能量传递。
def wall(a,wi,he) :
    if a.posx<=57.7/2 : 
        a.v = vec(abs(a.v.name[0]),a.v.name[1])
    if a.posy<=57.7/2 :
        a.v = vec(a.v.name[0],abs(a.v.name[1]))
    if a.posx>=wi-57.7/2 :
        a.v=vec(-abs(a.v.name[0]),a.v.name[1])
    if a.posy>=he-57.7/2 :
        a.v = vec(a.v.name[0],-abs(a.v.name[1]))
def check(ball,wi,he) :
    for i in ball :
        wall(i,wi,he)
        
    #for i in range(len(ball)) :
        
    for i in range(len(ball)) :
        if ball[i].v.lenth > 3 :
            record = i
            break
    record1=len(ball)
    while not record==record1 :
        for j in range(len(ball)) :
                for t in range(j+1,len(ball)):
                    if modify_something2(ball[j],ball[t]) :
                        hit(ball[j],ball[t])
#79~82行的代码可以检测整个列表的碰撞，并且完成能量的传递，特点在于，单向检测，一次检测循环完成可以达到这样的效果:列表前端的球的能量可以向后传递给与它相互接触的球，直至最后一颗有接触关系的球，但是列表末端的球只能将能量向前传递一颗球。
        record1=record
        for i in range(len(ball)) :
            if ball[i].v.lenth > 3 :
                record = i
                break
#总而言之，这个函数可以较好的应对相互连接等情况下的碰撞，但是如果整个列表的所有球的位置串联成环，程序会陷入死循环
#此种情况下应该替换其他函数。
    '''while record=record1 :
        for j in range(len(ball)-1,-1,-1) :
                for t in range(j-1,-1,-1):
                    if modify_something2(ball[j],ball[t]):
                        hit(ball[j],ball[t])
    else :
        for j in range(len(ball)) :
                for t in range(j+1,len(ball)):
                    if modify_something2(ball[j],ball[t]) :
                        hit(ball[j],ball[t])'''
    ''' wall(a,wi,he)
    wall(b,wi,he)
    
    if modify_something2(a,b)==1 :
        
        hit(a,b)
    elif modify_something2(a,b)==2 :
        hit(a,b)
        '''
if __name__ == '__main__' :
    a=Ball1((100,100),v=vec(0,8))
    b=Ball1((100,155),v=vec(0,0))
    print('a')
    print(a.v)
    print('b')
    print(b.v)
    hit(a,b)
    print('a')
    print(a.v)
    print('b')
    print(b.v)
    

    