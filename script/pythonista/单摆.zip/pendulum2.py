#coding:utf_8

'''
这是一个有阻尼和驱动的单摆，并不好看，也没有什么意思

'''
from scene import *
from Draw_line import my_line
from math import atan2,degrees,sin,cos
from numpy import *
font = ('Anonymous Pro',25)
pic = Texture('emj:Blue_Circle')

class pen(Scene) :
	
	def setup(self) :
		self.background_color = '#fdffdc'
		'''self.txt = LabelNode('I am here',font,parent=self)
		self.txt.anchor_point = (0.5,0.5)
		self.txt.position = (self.size.w/2,self.size.h/3)
		self.txt.color='#000000'
		'''
		#self.line = []
		self.ball = SpriteNode(pic,parent=self)
		self.ball.anchor_point = (0.5,0.5)
		self.ball.z_position = 2
		self.ball.position = (self.size.w/2,self.size.h/2)
		#设置球，位置并不准确，无所谓，应为这个你大概根本看不到
		self.flage = True #用于确保在重新移动球的位置时update不运行，我也不知道有无必要
		self.px = self.size.w/2
		self.py = 2*self.size.h/3 #这两个值记录了绳子的固定点，经常用，所以做一下重新命名
		self.theta = 0
		#记录当前小球的角度，与270度方向的夹角
		a,b = my_line(self.px,self.py,300,degrees(self.theta)+270,tp=False)
		self.l1 = ShapeNode(a,stroke_color = '#ff0000',parent = self)
		self.l1.anchor_point = (0.5,0.5)
		self.l1.position = b
		#初始化一条绳子，之后更新绳子的位置时，没想到其他办法，只能删除这条，重画一条。
		
		self.g = 9.8
		self.l = 1
		self.r = 300
		self.out = array([0,0,2/3])
		self.beta = 0.1
		#设置基础物理参数，重力加速度，绳长，真实绳长，以及在计算下一个角度时要使用的一个数组
		#考虑到计算方便，数组统一使用array，换句话说，用了numpy
	def update(self) :
		if self.flage :
			h = 0.0167
			f = lambda x : array([x[1],-self.g*sin(x[0])/self.l-2*self.beta*x[1]+0.8*cos(x[2]),2/3])
			#self.out = array([self.theta,0])
			k1 = h*f(self.out)
			k2 = h*f(self.out+k1/2)
			k3 = h*f(self.out+k2/2)
			k4 = h*f(self.out+k3)
			self.out = self.out + (k1+2*k2+2*k3+k4)/6
			self.theta = self.out[0]
			self.ball.position = (self.px+self.r*sin(self.theta),self.py-self.r*cos(self.theta))
			#以上为四阶龙格库塔法核心代码，需要注意计算过程始终使用弧度制
			
			
			self.l1.remove_from_parent()
			a,b = my_line(self.px,self.py,300,degrees(self.theta)+270,tp=False)
			self.l1 = ShapeNode(a,stroke_color = '#ff0000',parent = self)
			self.l1.anchor_point = (0.5,0.5)
			self.l1.position = b
			#每一帧都需要重设绳子的位置，首先必须要从节点树中将原绳子移除，然后在新的位置重画一条
			
			
	def touch_moved(self,touch) :
		self.flage = False
		x,y = touch.location
		theta = atan2(x-self.px,self.py-y)
		self.ball.position = (self.px+self.r*sin(theta),self.py-self.r*cos(theta))
		#self.txt.text = str(self.flage)
		#每次拖动小球的时候，都会实时的计算角度，重设小球的位置，因为要保证小球只在圆周上运动，所以不能直接将小球的位置设置为touch发生的点
		
		self.l1.remove_from_parent()
		a,b = my_line(self.px,self.py,300,degrees(theta)+270,tp=False)
		self.l1 = ShapeNode(a,stroke_color = '#ff0000',parent = self)
		self.l1.anchor_point = (0.5,0.5)
		self.l1.position = b
		#同样的，重设绳子
		
	def touch_ended(self,touch) :
		self.flage = True
		x,y = touch.location
		self.theta = atan2(x-self.px,self.py-y)
		#self.txt.text = str(self.theta)
		self.out = array([self.theta,0,2/3])
		#利用这个函数在拖动结束后重设角度，开启flage，重设out，有了out，update里面才会重新计算，换句话说这个程序里面out变量才是决定小球动不动的.
		
run(pen(),PORTRAIT,show_fps = True)
