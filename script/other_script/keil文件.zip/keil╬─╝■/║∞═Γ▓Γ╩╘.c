# include<STC12C2052AD.H>

 sbit  led2=P1^6;
 sbit  led3=P1^5;
 sbit  led4=P1^4;



 void delay(int a) //��ʱ��������λ����
{   int i;
    while(--a!=0)
    {for(i=0;i<600;i++);}
}
	   
void int1()
{		  
  EA=1;
  EX0=1;
   EX1=1;
  IT1=1;
  IT0=1;
  
  
}

void intus0() interrupt 0 using 2
{
  led3=1;
  delay(500);
  led3=0;
}
void intus2() interrupt 2 using 2
{
  led2=1;
  delay(500);
  led2=0;
}


void main()
{
   int t=0;
   int1();
 while(1)
 { 
   
   
     led4=1;
	 delay(500);
	 led4=0;

  }
  }