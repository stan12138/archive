# include<STC12C2052AD.H>
 
 sbit  tr=P1^0;
 sbit  ec=P3^7;


  void delay(int a) //��ʱ��������λ����
{   int i;
    while(--a!=0)
    {for(i=0;i<1;i++);}
}
void main()
{ ec=1;
  tr=0;
  while(1)
  { 
    ec=0;
	delay(2);
	ec=1;
    tr=0;
	delay(1);
	tr=1;
	delay(60);
	tr=0;
	delay(2);
	}
  }