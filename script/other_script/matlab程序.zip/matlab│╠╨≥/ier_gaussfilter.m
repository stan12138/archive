function y = ier_gaussfilter( x )
%��˹�˲���
%   �԰�λ�Ҷ�ͼ����и�˹�˲�
[m,n]=size(x);
y=x;
for i=1:m
   for j=1:n
       a=0;
       for s=-3:3
           for t=-3:3
             if ((i-s)>=1)&& ((i-s)<=m)&&((j-t)>=1)&&((j-t)<=n)   
                a=a+x(i-s,j-t)/(exp((((s)^2+(t)^2)*2))*((2*pi)^(1/2))*4);
             end
           end
       end
      y(i,j)=a;
    
   end
   
end
y=y;

end

