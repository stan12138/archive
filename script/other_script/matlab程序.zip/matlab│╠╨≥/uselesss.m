function [ x,y,x1,y1 ] = uselesss( z )
%һ����ʱʹ�õķ��ຯ��
%   �˴���ʾ��ϸ˵��
[m,n]=size(z);
j=0;
for i=1:m
    if z(i,3)==0
        j=j+1;
    end

end
j
x=ones(j,1);
y=ones(j,1);
x1=ones(m-j,1);
y1=ones(m-j,1);
j=1;
j1=1;
for i=1:m
    if z(i,3)==0
        x(j)=z(i,1);
        y(j)=z(i,2);
        j=j+1;
    else
        x1(j1)=z(i,1);
        y1(j1)=z(i,2);
        j1=j1+1;
    end
end
end

