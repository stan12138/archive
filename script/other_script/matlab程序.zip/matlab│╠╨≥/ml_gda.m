function ml_gda(x,y)
%һ����ΪGDA�Ļ���ѧϰ�㷨
%   ������Ϊ��˹�б�������мලѧϰ�㷨������(x,y)Ϊһ��������xΪ������yΪ���
[m,n]=size(x);
j=0;
for i=1:n
    if y(i)==1
        j=j+1;
    end
end
phi=j/n
j1=[0,0,0,0];
for i=1:n
    if y(i)==1
       j1(1)=j1(1)+x(1,i);
       j1(2)=j1(2)+x(2,i);
    else
       j1(3)=j1(3)+x(1,i);
       j1(4)=j1(4)+x(2,i);
    end
end
miu0=[j1(1)/(n-j);j1(2)/(n-j)]
miu1=[j1(3)/j;j1(4)/j]
sigma=[0,0;0,0];
for i=1:n
    if y(i)==0
        sigma(1,1)=sigma(1,1)+(x(1,i)-miu0(1))^2;
        sigma(1,2)=sigma(1,2)+(x(1,i)-miu0(1))*(x(2,i)-miu0(2));
        sigma(2,2)=sigma(2,2)+(x(2,i)-miu0(2))^2;
    else
        sigma(1,1)=sigma(1,1)+(x(1,i)-miu1(1))^2;
        sigma(1,2)=sigma(1,2)+(x(1,i)-miu1(1))*(x(2,i)-miu1(2));
        sigma(2,2)=sigma(2,2)+(x(2,i)-miu1(2))^2;
    end
end
sigma(2,1)=sigma(1,2);
sigma=sigma./n
sigma1=[0,0;0,0];
sigma1(1,1)=sigma(2,2)/(sigma(1,1)*sigma(2,2)-sigma(1,2)*sigma(2,1));
sigma1(1,2)=sigma(1,2)/(sigma(2,1)*sigma(1,2)-sigma(1,1)*sigma(2,2));
sigma1(2,1)=sigma(2,1)/(sigma(2,1)*sigma(1,2)-sigma(1,1)*sigma(2,2));
sigma1(2,2)=sigma(1,1)/(sigma(1,1)*sigma(2,2)-sigma(1,2)*sigma(2,1));
sigma1

end

