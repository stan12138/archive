import sys,pygame,time
from pygame.locals import *
from helpfile.white_chess import White_chess
from helpfile.black_chess import Black_chess
from ai.white_ai import white_decision_and_reaction
from ai.black_ai import black_decision_and_reaction

from helpfile.tools import board_translate,time_translate,count_location,judge_end,judge,first_step,judeg_key,draw_background

pygame.init()                                   #初始化程序段
color = [100,150,200]    #背景颜色，随便改
screen = pygame.display.set_mode([1000,680])   #设置屏幕大小，绝对不可更改，如果更改，会造成程序完全崩溃
pygame.display.set_caption('Creat by 韩仪')    #设置标题
screen.fill(color)    #清次屏


hvh = pygame.image.load('picture/hvh.png').convert_alpha()          #加载所有图片，chessboard：棋盘,whitechess：白色棋子,blackchess：黑色棋子
hvb = pygame.image.load('picture/hvb.png').convert_alpha()          #white：白棋标记键,black：黑棋标记键,again：重选键,re ：悔棋键
hvw = pygame.image.load('picture/hvw.png').convert_alpha()         #white_1,black_1,again_1,re_1，分别为上述键的点亮版
c2 = pygame.image.load('picture/2.png').convert_alpha()
c3 = pygame.image.load('picture/3.png').convert_alpha()
c4 = pygame.image.load('picture/4.png').convert_alpha()
c5 = pygame.image.load('picture/5.png').convert_alpha()
c6 = pygame.image.load('picture/6.png').convert_alpha()
confirm = pygame.image.load('picture/confirm.png').convert_alpha()

hvh1 = pygame.image.load('picture/hvh1.png').convert_alpha()          #加载所有图片，chessboard：棋盘,whitechess：白色棋子,blackchess：黑色棋子
hvb1 = pygame.image.load('picture/hvb1.png').convert_alpha()          #white：白棋标记键,black：黑棋标记键,again：重选键,re ：悔棋键
hvw1 = pygame.image.load('picture/hvw1.png').convert_alpha()         #white_1,black_1,again_1,re_1，分别为上述键的点亮版
c21 = pygame.image.load('picture/21.png').convert_alpha()
c31 = pygame.image.load('picture/31.png').convert_alpha()
c41= pygame.image.load('picture/41.png').convert_alpha()
c51 = pygame.image.load('picture/51.png').convert_alpha()
c61 = pygame.image.load('picture/61.png').convert_alpha()
confirm1 = pygame.image.load('picture/confirm1.png').convert_alpha()

font=pygame.font.SysFont('simsunnsimsun',30)    #终局是要显示的字
mode = font.render('模式',True,[0,0,0])
class1 = font.render('等级',True,[0,0,0])

aim = [10,10,10]

mos_flage = False

def draw_menu() :

	screen.blit(mode,[10,70])
	screen.blit(hvh,[10,130])
	screen.blit(hvb,[310,130])
	screen.blit(hvw,[610,130])
	screen.blit(class1,[10,290])
	screen.blit(c2,[5,350])
	screen.blit(c3,[205,350])
	screen.blit(c4,[405,350])
	screen.blit(c5,[605,350])
	screen.blit(c6,[805,350])
	screen.blit(confirm,[800,540])
	
def translate_menu(aim,x,y) :
	if y<290:
		x+=40
		aim[0] = int(x/300)
	elif y<450 :
		aim[1] = int((x-5)/200)
	elif y>530 :
		if x>750 and (not aim[0]==10) and (not aim[1]==10) :
			aim[2] = 1
		if x>750 and aim[0]==0 :
			aim[2] = 1
	return aim
	
draw_menu()

while True :

	for event in pygame.event.get() :
		if event.type == QUIT :
			pygame.quit()
			sys.exit()
		elif event.type == MOUSEBUTTONDOWN :
			mos_flage = True
			downx,downy = event.pos
			aim = translate_menu(aim,downx,downy)
			
	screen.fill(color)    #清次屏
	draw_menu()
	if mos_flage :
		if aim[0] == 0 :
			screen.blit(hvh1,[10,130])
		elif aim[0] == 1 :
			screen.blit(hvb1,[310,130])
		elif aim[0] == 2 :
			screen.blit(hvw1,[610,130])
			
		if aim[1] == 0 :
			screen.blit(c21,[5,350])
		elif aim[1] == 1 :
			screen.blit(c31,[205,350])
		elif aim[1] == 2 :
			screen.blit(c41,[405,350])
		elif aim[1] == 3 :
			screen.blit(c51,[605,350])
		elif aim[1] == 4 :
			screen.blit(c61,[805,350])
		if aim[2] == 1 :
			screen.blit(confirm1,[800,540])
			
			
			
			
	pygame.display.update()
	
	if aim[2] == 1 :
		time.sleep(1)
		break
		
		
		
screen.fill(color)    #清次屏
pygame.display.update()



chessboard = pygame.image.load('picture/chessboard.png').convert_alpha()          #加载所有图片，chessboard：棋盘,whitechess：白色棋子,blackchess：黑色棋子
whitechess = pygame.image.load('picture/whitechess.png').convert_alpha()          #white：白棋标记键,black：黑棋标记键,again：重选键,re ：悔棋键
blackchess = pygame.image.load('picture/blackchess1.png').convert_alpha()         #white_1,black_1,again_1,re_1，分别为上述键的点亮版
white = pygame.image.load('picture/white.png').convert_alpha()
black = pygame.image.load('picture/black.png').convert_alpha()
again = pygame.image.load('picture/again.png').convert_alpha()
re = pygame.image.load('picture/re.png').convert_alpha()
white_1 = pygame.image.load('picture/white_1.png').convert_alpha()
black_1 = pygame.image.load('picture/black_1.png').convert_alpha()
again_1 = pygame.image.load('picture/again_1.png').convert_alpha()
re_1 = pygame.image.load('picture/re_1.png').convert_alpha()


font=pygame.font.SysFont('simsunnsimsun',60)    #终局是要显示的字
b_win = font.render('黑棋获胜',True,[255,0,0])
w_win = font.render('白棋获胜',True,[255,0,0])




w_c02 = White_chess([0,2],whitechess)                #初始化白棋的类
w_c12 = White_chess([1,2],whitechess)
w_c22 = White_chess([2,2],whitechess)
w_c32 = White_chess([3,2],whitechess)
w_c42 = White_chess([4,2],whitechess)
w_c03 = White_chess([0,3],whitechess)
w_c13 = White_chess([1,3],whitechess)
w_c23 = White_chess([2,3],whitechess)
w_c33 = White_chess([3,3],whitechess)
w_c43 = White_chess([4,3],whitechess)
w_c04 = White_chess([0,4],whitechess)
w_c14 = White_chess([1,4],whitechess)
w_c24 = White_chess([2,4],whitechess)
w_c34 = White_chess([3,4],whitechess)
w_c44 = White_chess([4,4],whitechess)

b_c0 = Black_chess([0,0],blackchess)               #初始化黑棋的类
b_c2 = Black_chess([2,0],blackchess)
b_c4 = Black_chess([4,0],blackchess)


white_list = [w_c02,w_c12,w_c22,w_c32,w_c42,w_c03,w_c13,w_c23,w_c33,w_c43,w_c04,w_c14,w_c24,w_c34,w_c44] #初始化白棋列表
black_list = [b_c0,b_c2,b_c4]                              #初始化黑棋列表


#常规操作
board = [[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]]  #这个才是真正的初始化棋盘，棋盘空白化，特别备注，因为0==False的问题，此处特别将棋盘空白处设置为1
for i in white_list :      #往棋盘中添加黑白棋
	board[i.posy][i.posx] = i
for i in black_list :
	board[i.posy][i.posx] = i
	
for i in white_list :      #使用棋盘列表，对每一个棋子进行一次搜索，订出他们的上下左右的关系，特别的对于黑棋，标记出它可以攻击的棋子
	i.chess_search(board)
for i in black_list :
	i.chess_search(board,white_list)
	
	
	
white_flage = False        #标志程序段，包括白棋走棋（白棋标志位为False时黑棋走棋），重选，悔棋，鼠标点击标志
mos_flage = False          #鼠标进行了点击的标志位
chose_location = False     #选择位置的标志位,为真时选择位置，为假时选择棋子
end = False                #终局标志位
old_list = [1,0,0]              #初始化记录上一步的列表
be_chose = [10,10]         #初始化位置选择的列表


lo = []
m_t = []


record_file = open('record/chess_record.txt','a')       #有关记录的代码段
title = time_translate(aim[0])
record_file.write(title+'\n')
record_file.close()
step = 0

draw_background(screen,chessboard,whitechess,blackchess,white,black_1,again,re)  #绘制一次


while True :

	for event in pygame.event.get() :
		if event.type == QUIT :
			pygame.quit()
			sys.exit()
		elif event.type == MOUSEBUTTONDOWN :
			mos_flage = True
			downx,downy = event.pos
			downx,downy = count_location(downx,downy)
	if aim[0] == 2 :
		if  white_flage :
			if not chose_location :
				lo,m_t = white_decision_and_reaction(board,white_list,black_list,aim[1]+2)  #白棋智能决断，调整加号后面的数字即可动态调整聪明程度
				downy,downx = lo
			else :
				downy,downx = m_t
			mos_flage = True
			
	elif aim[0] == 0 :
		pass
		
	elif aim[0] == 1 :
		if not white_flage :
			if not chose_location :
				lo,m_t = black_decision_and_reaction(board,white_list,black_list,aim[1]+2)   #黑棋智能决断，调整加号后面的数字即可动态调整聪明程度
			if not chose_location :
				downy,downx = lo
			else :
				downy,downx = m_t
			#print(downx,downy)
			mos_flage = True
			
	if mos_flage :
	
	#负责记录的代码段
		if not chose_location :
			record_file = open('record/chess_record.txt','a')
			board_record = board_translate(board,black_list,white_list)
			record_file.write('step:%s'%step+'  '+str(board_record)+'\n')
			record_file.close()
			step+=1
			
			
		first_step(screen,color,chessboard,white,black,white_1,black_1,re,again,white_flage)  #仅负责重绘棋盘和黑白手指示按键
		
		if downx == 5 :
			white_list,black_list,white_flage,chose_location,old_list = judeg_key(screen,again_1,re_1,downx,downy,white_flage,chose_location,white_list,black_list,old_list)
		else :
			white_list,black_list,white_flage,chose_location,old_list,be_chose = judge(be_chose,screen,board,white_list,black_list,downx,downy,white_flage,chose_location,old_list)
			
			
			
		board = [[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]] #空白化棋盘，以待刷新
		for i in white_list :   #从白棋列表中清除被杀掉的棋子
			if not i.live :
				white_list.remove(i)
		for i in white_list :        #刷新棋盘
			board[i.posy][i.posx] = i
		for i in black_list :
			board[i.posy][i.posx] = i
			
			
			
			
		for i in white_list :        #刷新棋盘
			screen.blit(whitechess,i.rec)
			i.chess_search(board)
		for i in black_list :
			screen.blit(blackchess,i.rec)
			i.chess_search(board,white_list)
			#print(i.up,i.down,i.left,i.right)
			
			
		if white_flage :            #重新绘制黑白手棋标志
			screen.blit(white_1,[72,225])
			screen.blit(black,[72,100])
			
		else :
			screen.blit(white,[72,225])
			screen.blit(black_1,[72,100])
			
		if not be_chose[0] == 10 :   #画圈
			pygame.draw.circle(screen,[255,0,0],[be_chose[0]*150+350,be_chose[1]*150+40],75,2)
			
		mos_flage = False   #鼠标点击后进行以上处理
		
		
	pygame.display.update()
	
	end = judge_end(white_list,black_list)  #终局判定
	
	if end :
		if end == 1 :      #如果终局，根据输赢情况，打印文字
			screen.blit(b_win,[500,340])
			record_file = open('record/chess_record.txt','a')
			
			record_file.write('black win'+'\n')
			record_file.close()
			pygame.display.update()
			while True :    #等待退出
				for event in pygame.event.get() :
					if event.type == QUIT :
						pygame.quit()
						sys.exit()
		if end == 2 :
			screen.blit(w_win,[500,340])
			record_file = open('record/chess_record.txt','a')
			
			record_file.write('white win'+'\n')
			record_file.close()
			pygame.display.update()
			while True :
				for event in pygame.event.get() :
					if event.type == QUIT :
						pygame.quit()
						sys.exit()

