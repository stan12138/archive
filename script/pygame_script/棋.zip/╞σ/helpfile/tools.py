from time import localtime
from copy import deepcopy



def board_translate(board,black_list,white_list):
    board1 = [[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]]   #产生一个用数字标识的棋盘
    for i in range(5):
        for j in range(5) :
            if board[i][j] in black_list :
                board1[i][j] = 3
            if board[i][j] in white_list :
                board1[i][j] = 2
    return board1


def time_translate(mode) :           #进行时间格式转换
    t = 'time:'
    rec = localtime()
    for i in range(6) :
        if i>=3:
            t+=str(rec[i])
            if i <5 :
                t+=':'
        else :
            t+=str(rec[i])
            t+='.'
    if mode == 0 :
        t +=' author: stan han, mode: human vs human'
    elif mode == 1 :
        t +=' author: stan han, mode: human vs black_ai'
    elif mode == 2 :
        t +=' author: stan han, mode: human vs white_ai'
    return t

def count_location(x,y) :     #根据鼠标的坐标，计算指向棋盘上的元素，将像素坐标翻译为棋盘坐标和按键坐标
    if x>=275 :
        result_x = int((x-275)/150)
        if y <= 115 :
            result_y = 0
        else :
            result_y = int((y-115)/150)+1
    else :
        result_x = 5             #进行按键坐标的翻译，若翻译结果是按键坐标，则将result_x设定为5，按键自上而下为0~3
        if y <= 210 :
            result_y = 0
        elif y <= 335 :
            result_y = 1
        elif y <= 460 :
            result_y = 2
        else :
            result_y = 3
    return [result_x,result_y]


def judge_end(white_list,black_list) :                       #负责判定棋局是否结束，棋局未结束返回False，黑棋获胜返回1，白棋获胜返回2
    end = False
    remember = 0
    if len(white_list) == 0 :
        end = 1
    for i in black_list :
        if i.up == 1 :
            remember += 1
        if i.down == 1 :
            remember += 1
        if i.left == 1 :
            remember += 1
        if i.right == 1 :
            remember += 1
    if remember == 0 :
        end = 2

    return end

def judge(bechose,displayscreen,board,whitelist,blacklist,x,y,whiteflage,choselocation,oldlist) :              #判断鼠标对棋盘的选择合法与否，
    ju_flage = True      #函数内用于标记的私有变量
    help_list = []
    if whiteflage :     # 如果现在是白手
        if choselocation :         #如果现在该选择位置
            if not board[y][x] == 1 :  #根据棋盘布局判断，如果鼠标选择的位置不是空位，标志位置False
                ju_flage = False
            else :
                for i in whitelist :    #搜索白棋的列表，找出被选择的棋子
                    if i.chose  :
                        if abs(i.posx-x)+abs(i.posy-y)==1 :    #如果该位置是空位，同时被选中的棋子可以移动到此位置，则认为操作有效，执行动作
                            i.chose = False      #取消这个棋子的被选择标志位
                            help_list.append(deepcopy(whitelist))
                            help_list.append(deepcopy(blacklist))
                            oldlist[oldlist[0]] = help_list
                            oldlist[0] += 1
                            if oldlist[0] == 3:
                                oldlist[0] = 1
                            i.update_position([x,y])      #更新白棋的坐标
                            
                            whiteflage = not whiteflage    #更改下棋方
                            bechose = [x,y]                #存储选中的位置，用于绘制圆圈，标记
                            choselocation = False      # 更改任务为选择棋子
                            
                        break
        else :          #如果现在要选白色棋子
            if board[y][x] in whitelist :    #通过棋盘坐标，确定鼠标点击的位置是否为白棋
                    if board[y][x].up == 1 or board[y][x].down == 1 or board[y][x].left == 1 or board[y][x].right == 1 :  #要求这个位置的白色棋子是可以移动的
                        board[y][x].chose = True   #满足要求，则把这个棋子的选中标志设置为真
                        choselocation = True   #开启选择位置的标志，更改下一步的任务
                        bechose = [x,y]   #记录选中的位置
                   
                    
                
        
    if not whiteflage :                   #如果现在是黑手
        if choselocation :    #如果当前的任务是选择位置
            for i in blacklist :     #搜索黑棋列表，发现被选中的棋子
                if i.chose :
                    if board[y][x] == 1 and abs(i.posx-x)+abs(i.posy-y)==1 :   #如果这个位置是一个空位，把标记设置为1
                        ju_flage = 1
                        i.chose = False
                        help_list.append(deepcopy(whitelist))
                        help_list.append(deepcopy(blacklist))
                        oldlist[oldlist[0]] = help_list
                        oldlist[0] += 1
                        if oldlist[0] == 3 :
                            oldist[0] = 1

                        i.update_position([x,y])
                        
                        whiteflage = not whiteflage
                        choselocation = False
                        
                        bechose = [x,y]
                    elif board[y][x] in i.attack :   #如果这个位置是被选中的黑棋可以攻击的一颗白棋，把标记设置为2
                        ju_flage = 2
                        for j in i.attack :
                            i.chose = False
                            if board[y][x] == j :  #找到被攻击的白棋  


                                help_list.append(deepcopy(whitelist))
                                help_list.append(deepcopy(blacklist))
                                oldlist[oldlist[0]] = help_list
                                oldlist[0] += 1
                                if oldlist[0] == 3 :
                                    oldist[0] = 1
                                i.update_position([x,y])    #更新黑棋坐标                                    
                                j.live = False                    #把这颗白棋的生还标志设置为假
                                whiteflage = not whiteflage
                                choselocation = False
                                bechose = [x,y]

                    else :
                        ju_flage = False  #如果无法移动，标记设置为假
                        
        else :     #如果当前任务是选择黑色棋子
            if board[y][x] in blacklist :
                if board[y][x].up == 1 or board[y][x].down == 1 or board[y][x].left == 1 or board[y][x].right == 1 : #做同白棋同样的处理
                        board[y][x].chose = True
                        choselocation = True
                        bechose = [x,y]
    return [whitelist,blacklist,whiteflage,choselocation,oldlist,bechose]  #返回更新后的黑，白棋列表，手棋标志位，任务标志，旧的位置列表，被选择项


def first_step(screen,color,chessboard,white,black,white_1,black_1,re,again,white_flage) :   #鼠标被按下之后进行的第一步操作
    screen.fill(color)                        #清屏，重绘棋盘，重绘按键
    screen.blit(chessboard,[330,20])
    screen.blit(again,[72,350])
    screen.blit(re,[72,475])
    if white_flage :
            screen.blit(white_1,[72,225])
            screen.blit(black,[72,100])
            
    else :
            screen.blit(white,[72,225])
            screen.blit(black_1,[72,100])

def judeg_key(screen,again_1,re_1,downx,downy,white_flage,chose_location,white_list,black_list,old_list):   #判断鼠标对按键的选择
            help_list = []
            if downy == 2 and chose_location:      #在下一步任务是选择位置的情况下，点击了重选按键
                screen.blit(again_1,[72,350])  #点亮重选按键
                if white_flage :            #在黑白棋列表里找到已经被选中的棋子，把它的被选标志重设为假
                    for i in white_list :
                        if i.chose == True :
                            i.chose = False
                else :
                    for i in black_list :
                        if i.chose == True :
                            i.chose = False
                chose_location = False   #改变当前任务为选择棋子
            elif downy == 3 :            #如果点击了悔棋按键
                screen.blit(re_1,[72,475])  #点亮这个按键
                if old_list[old_list[0]] == 0:    #如果记录上一步的列表是1，说明刚开局，没有上一步
                    pass
                else :
                    help_list = old_list[old_list[0]]
                    white_list = deepcopy(help_list[0])
                    black_list = deepcopy(help_list[1])
                    chose_location = False
            return [white_list,black_list,white_flage,chose_location,old_list]           



def draw_background(screen,chessboard,whitechess,blackchess,white,black_1,again,re) :        #绘制背景，只调用一次
    wh_rec = whitechess.get_rect()
    bl_rec = blackchess.get_rect()

    screen.blit(chessboard,[330,20])
    screen.blit(white,[72,225])
    screen.blit(black_1,[72,100])
    screen.blit(again,[72,350])
    screen.blit(re,[72,475])
   
    bl_rec.center = [350,40]
    screen.blit(blackchess,bl_rec)
    bl_rec.center = [650,40]
    screen.blit(blackchess,bl_rec)
    bl_rec.center = [950,40]
    screen.blit(blackchess,bl_rec)

    for i in range(340,641,150) :
        for j in range(350,951,150) :
            wh_rec.center = [j,i]
            screen.blit(whitechess,wh_rec)