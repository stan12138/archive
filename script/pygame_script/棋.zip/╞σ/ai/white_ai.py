# coding: utf-8
# coding: utf-8
#做一个统一的名称，与屏幕坐标一致的坐标，也即与屏幕上的棋盘画面使用的坐标相同的坐标，称之为坐标，但是棋盘存储使用的坐标于此并不一致
#称棋盘存储使用的坐标为棋盘坐标，这个坐标只有board在使用，从board转换到其他，要将坐标调换，从坐标转换到棋盘坐标也要进行坐标调换

#2016.4.17 已剪枝

def white_decision_and_reaction(board,whi_list,bla_list,max_deep) :
	board1 = translate(board,whi_list,bla_list)
	first = node(board1,False,0)
	now = max_min(first,max_deep)
	#print(now)
	loc = []
	move_to = []
	for i in range(5) :
		for j in range(5) :
			if first.board[i][j] == 2 and not now[i][j] == 2 :
				loc = [i,j]
			if now[i][j] == 2 and not first.board[i][j] == 2 :
				move_to = [i,j]
	return loc,move_to
	
	
	
def evaluate(a) :
	a.search()
	number = 0
	
	number = len(a.w_list)
	move_num = 0
	attack_num = 0
	for i in a.b_list :
		if i.right :
			move_num+=1
		if i.left :
			move_num+=1
		if i.up :
			move_num+=1
		if i.down :
			move_num+=1
		for j in i.attack :
			if not j :
				attack_num+=1
	return 6*number+3*attack_num+12-move_num
def max_min(a,max_deep) :
	v = max_value(a,-1000,1000,max_deep)
	#print(v)
	for i in a.child :
		if i.value == v :
			return i.board
def max_value(a,alpha,beta,max_deep) :
	if a.deep == max_deep :
		a.value = evaluate(a)
		return a.value
	v =-1000
	a.search()
	a.next()
	for i in a.child :
		v = max(v,min_value(i,alpha,beta,max_deep))
		if v>= beta :
			a.value = v
			return v
		alpha = max(alpha,v)
	a.value = v
	return v
def min_value(a,alpha,beta,max_deep) :
	if a.deep == max_deep :
		a.value = evaluate(a)
		return a.value
	v = 1000
	a.search()
	a.next()
	for i in a.child :
		v = min(v,max_value(i,alpha,beta,max_deep))
		if v <= alpha :
			a.value = v
			return v
		beta = min(beta,v)
	a.value = v
	return v
class W :
	def __str__(self) :
		return '白 '+'position:%s'%[self.posx,self.posy]+'  上下左右  '+str(self.up)+'  '+str(self.down)+'   '+str(self.left)+'  '+str(self.right)
		
	def __init__(self,position) :
		self.posx ,self.posy = position  # pos指在棋盘上的坐标，左上角为（0，0）
		
		
	def update_position(self,position) :
		self.posx , self.posy = position
		
		
		
	def chess_search(self,board) :
		self.right = False
		self.left = False
		self.up = False
		self.down = False
		if self.posx <4 :
			if board[self.posy][self.posx+1] == 1 :
				self.right = True
               # print(self.posx,self.posy,'could right','right is',board[self.posy][self.posx+1])
               # print(self.posy,self.posx+1)

		if self.posx >0 :
			if board[self.posy][self.posx-1] == 1 :
				self.left = True
				#print(self.posx,self.posy,'could left','left is',board[self.posy][self.posx-1])
				#print(self.posy,self.posx-1)
				
		if self.posy <4 :
			if board[self.posy+1][self.posx] == 1 :
				self.down = True
              #  print(self.posx,self.posy,'could down','down is',board[self.posy+1][self.posx])
              #  print(self.posy+1,self.posx)

		if self.posy >0 :
			if board[self.posy-1][self.posx] == 1 :
				self.up = True
               # print(self.posx,self.posy,'could up','up is ',board[self.posy-1][self.posx])
               # print(self.posy-1,self.posx)



class B :
	def __str__(self) :
		return '黑 '+'position:%s'%[self.posx,self.posy]+'  上下左右%s'%[self.up,self.down,self.left,self.right]+'  攻击%s'%self.attack
	def __init__(self,position) :
		self.posx ,self.posy = position  # pos指在棋盘上的坐标，左上角为（0，0）
		
		
	def update_position(self,position) :
		self.posx , self.posy = position
		
		
		
	def chess_search(self,board) :        #黑棋的标记，上下左右为真，表示可以向该方向移动，攻击列表有四位，为真的位即为攻击对象的坐标
		self.right = False
		self.left = False
		self.down = False
		self.up = False
		if self.posx <4 :
			if board[self.posy][self.posx+1] == 1 :
				self.right = True
				
		if self.posx >0 :
			if board[self.posy][self.posx-1] == 1 :
				self.left = True
		if self.posy <4 :
			if board[self.posy+1][self.posx] == 1 :
				self.down = True
				
		if self.posy >0 :
			if board[self.posy-1][self.posx] == 1 :
				self.up = True
				
		self.attack = [False,False,False,False]
		if self.up == 1 and self.posy >1 :
			if board[self.posy-2][self.posx]==2 :
				self.attack[0] = [self.posx,self.posy-2]
				
		if self.down == 1 and self.posy <3 :
			if board[self.posy+2][self.posx]==2 :
				self.attack[1] = [self.posx,self.posy+2]
				
		if self.left == 1 and self.posx >1 :
			if board[self.posy][self.posx-2] ==2 :
				self.attack[2] = [self.posx-2,self.posy]
				
		if self.right == 1 and self.posx <3 :
			if board[self.posy][self.posx+2] ==2 :
				self.attack[3] = [self.posx+2,self.posy]
				
				
				
				
				
				
				
def translate(board,whitelist,blacklist) :
	board1 = [[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]]
	
	for i in range(5) :
		for j in range(5) :
			if board[i][j] in whitelist :
			
				board1[i][j] = 2
				
			if board[i][j] in blacklist :
				board1[i][j] = 3
	return board1
	
	
	
class node :
	def __str__(self) :
		return str(self.board)
	def __init__(self,board,name,deep) :
		self.board = board
		self.name = name    #name标志此节点是谁的手棋，True白，False黑
		self.deep = deep
		self.value = -100
		
	def search(self) :
		self.w_list = []
		self.b_list = []
		for i in range(5) :
			for j in range(5) :
				if self.board[i][j] == 2 :
					a = W([j,i])
					self.w_list.append(a)
					
				if self.board[i][j] == 3 :
					a = B([j,i])
					self.b_list.append(a)
					
		for i in self.w_list :
			i.chess_search(self.board)
		for i in self.b_list :
			i.chess_search(self.board)
       # for i in self.w_list :
       #     print(i)
       # for i in self.b_list :
       #     print(i)

	def next(self) :
		self.child = []
		if self.name :
			for i in self.b_list :
				if i.up :
					self.bo = [[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]]     #不知道为什么此处的a = b[:]的拷贝技术不起作用了，只能出此下策，sorry
					for w in range(5):
						for q in range(5):
							self.bo[w][q] = self.board[w][q]
					self.bo[i.posy][i.posx] = 1
					self.bo[i.posy-1][i.posx] = 3
					#print(self.board)
					a = node(self.bo,not self.name,self.deep+1)
					self.child.append(a)
				if i.down :
					self.bo = [[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]]
					for w in range(5):
						for q in range(5):
							self.bo[w][q] = self.board[w][q]
							
					self.bo[i.posy][i.posx] = 1
					self.bo[i.posy+1][i.posx] = 3
					#print(self.board)
					a = node(self.bo,not self.name,self.deep+1)
					self.child.append(a)
				if i.left :
					self.bo = [[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]]
					for w in range(5):
						for q in range(5):
							self.bo[w][q] = self.board[w][q]
							
					self.bo[i.posy][i.posx] = 1
					self.bo[i.posy][i.posx-1] = 3
					a = node(self.bo,not self.name,self.deep+1)
					self.child.append(a)
				if i.right :
					self.bo = [[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]]
					for w in range(5):
						for q in range(5):
							self.bo[w][q] = self.board[w][q]
							
					self.bo[i.posy][i.posx] = 1
					self.bo[i.posy][i.posx+1] = 3
					a = node(self.bo,not self.name,self.deep+1)
					self.child.append(a)
				for j in i.attack :
					if j :
						self.bo = [[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]]
						for w in range(5):
							for q in range(5):
								self.bo[w][q] = self.board[w][q]
								
						self.bo[i.posy][i.posx] = 1
						self.bo[j[1]][j[0]] = 3
						a = node(self.bo,not self.name,self.deep+1)
						self.child.append(a)
		else :
			for i in self.w_list :
				if i.up :
					self.bo = [[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]]
					for w in range(5):
						for q in range(5):
							self.bo[w][q] = self.board[w][q]
							
					self.bo[i.posy][i.posx] = 1
					self.bo[i.posy-1][i.posx] = 2
					
					a = node(self.bo,not self.name,self.deep+1)
					self.child.append(a)
				if i.down :
					self.bo = [[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]]
					for w in range(5):
						for q in range(5):
							self.bo[w][q] = self.board[w][q]
							
					self.bo[i.posy][i.posx] = 1
					self.bo[i.posy+1][i.posx] = 2
					a = node(self.bo,not self.name,self.deep+1)
					self.child.append(a)
				if i.left :
					self.bo = [[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]]
					for w in range(5):
						for q in range(5):
							self.bo[w][q] = self.board[w][q]
							
					self.bo[i.posy][i.posx] = 1
					self.bo[i.posy][i.posx-1] = 2
					a = node(self.bo,not self.name,self.deep+1)
					self.child.append(a)
				if i.right :
					self.bo = [[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]]
					for w in range(5):
						for q in range(5):
							self.bo[w][q] = self.board[w][q]
							
					self.bo[i.posy][i.posx] = 1
					self.bo[i.posy][i.posx+1] = 2
					a = node(self.bo,not self.name,self.deep+1)
					self.child.append(a)
					
					
					
					
					
#w_c02 = W([0,2])                #初始化白棋的类
#w_c12 = W([1,2])
#w_c22 = W([2,2])
#w_c32 = W([3,2])
#w_c42 = W([4,2])
#w_c03 = W([0,3])
#w_c13 = W([1,3])
#w_c23 = W([2,3])
#w_c33 = W([3,3])
#w_c43 = W([4,3])
#w_c04 = W([0,4])
#w_c14 = W([1,4])
#w_c24 = W([2,4])
#w_c34 = W([3,4])
#w_c44 = W([4,4])

#b_c0 = B([0,0])               #初始化黑棋的类
#b_c2 = B([2,0])
#b_c4 = B([4,0])

#white_list = [w_c02,w_c12,w_c22,w_c32,w_c42,w_c03,w_c13,w_c23,w_c33,w_c43,w_c04,w_c14,w_c24,w_c34,w_c44] #初始化白棋列表
#black_list = [b_c0,b_c2,b_c4]                              #初始化黑棋列表
#board = [[b_c0,1,b_c2,1,b_c4],[1,1,1,1,1],[w_c02,w_c12,w_c22,w_c32,w_c42],[w_c03,w_c13,w_c23,w_c33,w_c43],[w_c04,w_c14,w_c24,w_c34,w_c44]]  #初始化棋盘

#board1 = translate(board,white_list,black_list)
#board1 = [[1,1,1,1,1],[1,1,1,1,1],[1,2,3,2,2],[3,2,3,2,1],[2,2,2,2,2]]
#print('this is board1',board1)
#first = node(board1,True,0)
#print('this is first',first)
#first.search()
#print('this is first',first)
#print('fist name',first.name)
#first.next()
#print('this is first',first)
#print('first child')
#for i in first.child :
#    print(i)
#t = max_min(first)
#print(t)
#decision_and_reaction(board,white_list,black_list)

