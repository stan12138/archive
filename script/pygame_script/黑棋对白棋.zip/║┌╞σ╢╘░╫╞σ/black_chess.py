class Black_chess :
    

    def __init__(self,position,image) :
        self.posx ,self.posy = position  # pos指在棋盘上的坐标，左上角为（0，0）
        self.rec = image.get_rect()
        self.rec.center = [self.posx*150+350,self.posy*150+40]
        self.chose = False

    def update_position(self,position) :
        self.posx , self.posy = position
        self.rec.center = [self.posx*150+350,self.posy*150+40]
        
         
    def chess_search(self,board,whitelist) :
        if self.posx <4 :
            self.right = board[self.posy][self.posx+1]
        else :
            self.right = False
        if self.posx >0 :
            self.left = board[self.posy][self.posx-1]
        else :
            self.left = False
        if self.posy <4 :
            self.down = board[self.posy+1][self.posx]
        else :
            self.down = False
        if self.posy >0 :
            self.up = board[self.posy-1][self.posx]
        else :
            self.up = False
        self.attack = [False,False,False,False]
        if self.up == 1 and self.posy >1 :
            if board[self.posy-2][self.posx] in whitelist :
                self.attack[0] = board[self.posy-2][self.posx]

        if self.down == 1 and self.posy <3 :
            if board[self.posy+2][self.posx] in whitelist :
                self.attack[1] = board[self.posy+2][self.posx]

        if self.left == 1 and self.posx >1 :
            if board[self.posy][self.posx-2] in whitelist :
                self.attack[2] = board[self.posy][self.posx-2]

        if self.right == 1 and self.posx <3 :
            if board[self.posy][self.posx+2] in whitelist :
                self.attack[3] = board[self.posy][self.posx+2]
            
