import sys,pygame
from pygame.locals import *
from white_chess import White_chess
from black_chess import Black_chess
import black_ai_vs as ba
import white_ai_vs as wa
from time import localtime
def board_translate(board,black_list,white_list):
    board1 = [[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]]
    for i in range(5):
        for j in range(5) :
            if board[i][j] in black_list :
                board1[i][j] = 3
            if board[i][j] in white_list :
                board1[i][j] = 2
    return board1
    
def time_translate() :
    t = 'time:'
    rec = localtime()
    for i in range(6) :
        if i>=3:
            t+=str(rec[i])
            if i <5 :
                t+=':'
        else :
            t+=str(rec[i])
            t+='.'
    t +=' author: stan han, mode: white_ai vs black_ai'
    return t
def count_location(x,y) :     #根据鼠标的坐标，计算指向棋盘上的元素，将像素坐标翻译为棋盘坐标和按键坐标
    if x>=275 :
        result_x = int((x-275)/150)
        if y <= 115 :
            result_y = 0
        else :
            result_y = int((y-115)/150)+1
    else :
        result_x = 5             #进行按键坐标的翻译，若翻译结果是按键坐标，则将result_x设定为5，按键自上而下为0~3
        if y <= 210 :
            result_y = 0
        elif y <= 335 :
            result_y = 1
        elif y <= 460 :
            result_y = 2
        else :
            result_y = 3
    return [result_x,result_y]

def count_translate_result(displayscreen,again,again_1,re,re_1,x,y) :        #根据count_location计算的结果进行绘制结果，此函数应该已经废弃
   
    
    if x < 5 :              # 如果鼠标操作对象是棋盘，对棋子画圆，标记
        x1 = x*150+350
        y1 = y*150+40
        
        pygame.draw.circle(displayscreen,[255,0,0],[x1,y1],75,2)
    else :
        
        if y == 2 :             # 如果鼠标对按键操作，只对“重选”和“悔棋”两个键做反应，高亮
           screen.blit(again_1,[72,350])
           screen.blit(re,[72,475])
        elif y == 3 :
           screen.blit(re_1,[72,475])
           screen.blit(again,[72,350])
    
    
        

def draw_background(screen,chessboard,whitechess,blackchess,white,black_1,again,re) :        #绘制背景，只调用一次
    wh_rec = whitechess.get_rect()
    bl_rec = blackchess.get_rect()

    screen.blit(chessboard,[330,20])
    screen.blit(white,[72,225])
    screen.blit(black_1,[72,100])
    screen.blit(again,[72,350])
    screen.blit(re,[72,475])
   
    bl_rec.center = [350,40]
    screen.blit(blackchess,bl_rec)
    bl_rec.center = [650,40]
    screen.blit(blackchess,bl_rec)
    bl_rec.center = [950,40]
    screen.blit(blackchess,bl_rec)

    for i in range(340,641,150) :
        for j in range(350,951,150) :
            wh_rec.center = [j,i]
            screen.blit(whitechess,wh_rec)


def judge_end(white_list,black_list) :                       #负责判定棋局是否结束，棋局未结束返回False，黑棋获胜返回1，白棋获胜返回2
    end = False
    remember = 0
    if len(white_list) == 0 :
        end = 1
    for i in black_list :
        if i.up == 1 :
            remember = remember+1
        if i.down == 1 :
            remember = remember+1
        if i.right == 1 :
            remember = remember+1
        if i.right == 1 :
            remember = remember+1
    if remember == 0 :
        end = 2
    return end

def judge(bechose,displayscreen,board,whitelist,blacklist,x,y,whiteflage,choselocation,oldlist) :              #判断鼠标对棋盘的选择合法与否，
    ju_flage = True      #函数内用于标记的私有变量
    
    if whiteflage :     # 如果现在是白手
        if choselocation :         #如果现在该选择位置
            if board[y][x] == 1 :  #根据棋盘布局判断，如果鼠标选择的位置不是空位，标志位置False
                pass
            else :
                ju_flage = False
            for i in whitelist :    #搜索白棋的列表，找出被选择的棋子
                if i.chose  :
                    if abs(i.posx-x)+abs(i.posy-y)==1 and ju_flage :    #如果该位置是空位，同时被选中的棋子可以移动到此位置，则认为操作有效，执行动作
                        oldlist = [i.posx,i.posy,x,y,0]        #存储旧棋盘，使用一个列表，列表长度为5，前两位储存原棋子的位置坐标，中间两位存储移动后的新坐标，最后一位：0：白棋移动
                        i.update_position([x,y])      #更新白棋的坐标
                        whiteflage = not whiteflage    #更改下棋方
                        bechose = [x,y]                #存储选中的位置，用于绘制圆圈，标记
                        choselocation = False      # 更改任务为选择棋子
                        i.chose = False      #取消这个棋子的被选择标志位
        else :          #如果现在要选白色棋子
            if board[y][x] in whitelist :    #通过棋盘坐标，确定鼠标点击的位置是否为白棋
                    if board[y][x].up == 1 or board[y][x].down == 1 or board[y][x].left == 1 or board[y][x].right == 1 :  #要求这个位置的白色棋子是可以移动的
                        board[y][x].chose = True   #满足要求，则把这个棋子的选中标志设置为真
                        choselocation = True   #开启选择位置的标志，更改下一步的任务
                        bechose = [x,y]   #记录选中的位置
                   
                    
                
        
    if not whiteflage :                   #如果现在是黑手
        if choselocation :    #如果当前的任务是选择位置
            for i in blacklist :     #搜索黑棋列表，发现被选中的棋子
                if i.chose == True :
                    if board[y][x] == 1  :   #如果这个位置是一个空位，把标记设置为1
                        ju_flage = 1
                    elif board[y][x] in i.attack :   #如果这个位置是被选中的黑棋可以攻击的一颗白棋，把标记设置为2
                        ju_flage = 2
                    else :
                        ju_flage = False  #如果无法移动，标记设置为假
            for i in blacklist :
                if i.chose  :    #搜索黑棋列表，发现被选中的棋子
                    if  ju_flage == 1 and abs(i.posx-x)+abs(i.posy-y)==1 :  #如果该位置是空位，同时被选中的棋子可以移动到此位置，则认为操作有效，执行动作
                        oldlist = [i.posx,i.posy,x,y,1]        #记录旧的位置，最后一为设置为1，标记这是黑棋做了移动
                        i.update_position([x,y])
                        whiteflage = not whiteflage
                        choselocation = False
                        i.chose = False
                        bechose = [x,y]
                    elif ju_flage == 2 :   #如果可以攻击
                        for j in i.attack :
                            if board[y][x] == j :  #找到被攻击的白棋
                                oldlist = [i.posx,i.posy,x,y,2]    #记录黑棋做了攻击   
                                j.live = False                    #把这颗白棋的生还标志设置为假
                                i.update_position([x,y])    #更新黑棋坐标
                                whiteflage = not whiteflage
                                choselocation = False
                                i.chose = False
                                bechose = [x,y]
                        
        else :     #如果当前任务是选择黑色棋子
            if board[y][x] in blacklist :
                if board[y][x].up == 1 or board[y][x].down == 1 or board[y][x].left == 1 or board[y][x].right == 1 : #做同白棋同样的处理
                        board[y][x].chose = True
                        choselocation = True
                        bechose = [x,y]
    return [whitelist,blacklist,whiteflage,choselocation,oldlist,bechose]  #返回更新后的黑，白棋列表，手棋标志位，任务标志，旧的位置列表，被选择项


def first_step(screen,color,chessboard,white,black,white_1,black_1,re,again,whiteflage) :   #鼠标被按下之后进行的第一步操作
    screen.fill(color)                        #清屏，重绘棋盘，重绘按键
    screen.blit(chessboard,[330,20])
    screen.blit(again,[72,350])
    screen.blit(re,[72,475])
    if white_flage :
            screen.blit(white_1,[72,225])
            screen.blit(black,[72,100])
            
    else :
            screen.blit(white,[72,225])
            screen.blit(black_1,[72,100])

def judeg_key(screen,again_1,re_1,downx,downy,white_flage,chose_location,white_list,black_list,old_list):   #判断鼠标对按键的选择
            if downy == 2 and chose_location:      #在下一步任务是选择位置的情况下，点击了重选按键
                screen.blit(again_1,[72,350])  #点亮重选按键
                if white_flage :            #在黑白棋列表里找到已经被选中的棋子，把它的被选标志重设为假
                    for i in white_list :
                        if i.chose == True :
                            i.chose = False
                else :
                    for i in black_list :
                        if i.chose == True :
                            i.chose = False
                chose_location = False   #改变当前任务为选择棋子
            elif downy == 3 :            #如果点击了悔棋按键
                screen.blit(re_1,[72,475])  #点亮这个按键
                if old_list == 1:    #如果记录上一步的列表是1，说明刚开局，没有上一步
                    pass
                elif old_list[4] == 3 :  #为了防止不断连续点击悔棋按键导致下棋方不断更改的现象
                    pass
                else :
                    if old_list[4] == 0 :     #根据记录的标志位恢复上一步的棋局
                        for i in white_list :
                            if i.posx == old_list[2] and i.posy == old_list[3] :
                                i.update_position([old_list[0],old_list[1]])
                    if old_list[4] == 1 :
                        for i in black_list :
                            if i.posx == old_list[2] and i.posy == old_list[3] :
                                i.update_position([old_list[0],old_list[1]])
                    if old_list[4] == 2 :
                        for i in black_list :
                            if i.posx == old_list[2] and i.posy == old_list[3] :
                                i.update_position([old_list[0],old_list[1]])
                        new = White_chess([old_list[2],old_list[3]],whitechess)
                        white_list.append(new)
                    old_list[4] = 3
                    white_flage = not white_flage
                    chose_location = False
            return [white_list,black_list,white_flage,chose_location,old_list]
    
    



pygame.init()                                   #初始化程序段
color = [100,150,200]    #背景颜色，随便改
screen = pygame.display.set_mode([1000,680])   #设置屏幕大小，绝对不可更改，如果更改，会造成程序完全崩溃
pygame.display.set_caption('Creat by 韩仪')    #设置标题
screen.fill(color)    #清次屏
    



chessboard = pygame.image.load('chessboard.png').convert_alpha()          #加载所有图片，chessboard：棋盘,whitechess：白色棋子,blackchess：黑色棋子
whitechess = pygame.image.load('whitechess.png').convert_alpha()          #white：白棋标记键,black：黑棋标记键,again：重选键,re ：悔棋键
blackchess = pygame.image.load('blackchess1.png').convert_alpha()         #white_1,black_1,again_1,re_1，分别为上述键的点亮版
white = pygame.image.load('white.png').convert_alpha()
black = pygame.image.load('black.png').convert_alpha()
again = pygame.image.load('again.png').convert_alpha()
re = pygame.image.load('re.png').convert_alpha()
white_1 = pygame.image.load('white_1.png').convert_alpha()
black_1 = pygame.image.load('black_1.png').convert_alpha()
again_1 = pygame.image.load('again_1.png').convert_alpha()
re_1 = pygame.image.load('re_1.png').convert_alpha()


w_c02 = White_chess([0,2],whitechess)                #初始化白棋的类
w_c12 = White_chess([1,2],whitechess)
w_c22 = White_chess([2,2],whitechess)
w_c32 = White_chess([3,2],whitechess)
w_c42 = White_chess([4,2],whitechess)
w_c03 = White_chess([0,3],whitechess)
w_c13 = White_chess([1,3],whitechess)
w_c23 = White_chess([2,3],whitechess)
w_c33 = White_chess([3,3],whitechess)
w_c43 = White_chess([4,3],whitechess)
w_c04 = White_chess([0,4],whitechess)
w_c14 = White_chess([1,4],whitechess)
w_c24 = White_chess([2,4],whitechess)
w_c34 = White_chess([3,4],whitechess)
w_c44 = White_chess([4,4],whitechess)

b_c0 = Black_chess([0,0],blackchess)               #初始化黑棋的类
b_c2 = Black_chess([2,0],blackchess)
b_c4 = Black_chess([4,0],blackchess)

white_list = [w_c02,w_c12,w_c22,w_c32,w_c42,w_c03,w_c13,w_c23,w_c33,w_c43,w_c04,w_c14,w_c24,w_c34,w_c44] #初始化白棋列表
black_list = [b_c0,b_c2,b_c4]                              #初始化黑棋列表
board = [[b_c0,0,b_c2,0,b_c4],[0,0,0,0,0],[w_c02,w_c12,w_c22,w_c32,w_c42],[w_c03,w_c13,w_c23,w_c33,w_c43],[w_c04,w_c14,w_c24,w_c34,w_c44]]  #初始化棋盘
board = [[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]]  #这个才是真正的初始化棋盘，棋盘空白化，特别备注，因为0==False的问题，此处特别将棋盘空白处设置为1
for i in white_list :              #往棋盘中添加黑白棋
        board[i.posy][i.posx] = i
for i in black_list :
        board[i.posy][i.posx] = i
for i in white_list :        #使用棋盘列表，对每一个棋子进行一次搜索，订出他们的上下左右的关系，特别的对于黑棋，标记出它可以攻击的棋子
        i.chess_search(board)
for i in black_list :
        i.chess_search(board,white_list)


white_flage = False          #标志程序段，包括白棋走棋（白棋标志位为False时黑棋走棋），重选，悔棋，鼠标点击标志

font=pygame.font.SysFont('simsunnsimsun',60)    #终局是要显示的字
b_win = font.render('黑棋获胜',True,[255,0,0])
w_win = font.render('白棋获胜',True,[255,0,0])
mos_flage = False          #鼠标进行了点击的标志位
chose_location = False     #选择位置的标志位,为真时选择位置，为假时选择棋子
end = False         #终局标志位
judge_flage = False   #这三个变量应该都没用
again_flage = False
re_flage = False
old_list = 1      #初始化记录上一步的列表
be_chose = [10,10]    #初始化位置选择的列表
draw_background(screen,chessboard,whitechess,blackchess,white,black_1,again,re)  #绘制一次
#pygame.display.update()
#pygame.image.save(screen,'screen.png')
lo = []
m_t = []
record_file = open('chess_record.txt','a')
title = time_translate()
record_file.write(title+'\n')
record_file.close()
step_i = 0
dead_loop = False
step = 0
while True :

    for event in pygame.event.get() :
        if event.type == QUIT :
            pygame.quit()
            sys.exit()
        elif event.type == MOUSEBUTTONDOWN :
            mos_flage = True
            downx,downy = event.pos
            downx,downy = count_location(downx,downy)

    if not white_flage :
        #print('i have come to here')
        if not chose_location :
            lo,m_t = ba.decision_and_reaction(board,white_list,black_list,False)
            
        if not chose_location :
            downy,downx = lo
        else :
            downy,downx = m_t
        #print(downx,downy)
        mos_flage = True
    if  white_flage :
        #print('counting')
        if not chose_location :
            #print(decision_and_reaction(board,white_list,black_list))
            lo,m_t = wa.decision_and_reaction(board,white_list,black_list,dead_loop)
            if step_i <3 :
                dead_loop = False
                dead = open('dead.txt','a')
                dead_record = board_translate(board,black_list,white_list)
                dead.write(str(dead_record)+'\n')
                dead.close()
                step_i += 1
            else :
                dead = open('dead.txt')
                dead1 = dead.readline()
                dead2 = dead.readline()
                dead3 = dead.readline()
                dead.close()
                dead1 = eval(dead1)
                dead3 = eval(dead3)
                if dead1 == dead3 :
                    dead_loop = True
                else :
                    dead_loop = False
                step_i = 1
                dead = open('dead.txt','w')
                dead_record = board_translate(board,black_list,white_list)
                dead.write(str(dead_record)+'\n')
                dead.close()
        if not chose_location :
            downy,downx = lo
        else :
            downy,downx = m_t
        #print(downx,downy)
        mos_flage = True
    if mos_flage :
        if not chose_location :
            record_file = open('chess_record.txt','a')
            board_record = board_translate(board,black_list,white_list)
            record_file.write('step:%s'%step+'  '+str(board_record)+'\n')
            record_file.close()
            step+=1

        first_step(screen,color,chessboard,white,black,white_1,black_1,re,again,white_flage)
        if downx == 5 :
            white_list,black_list,white_flage,chose_location,old_list = judeg_key(screen,again_1,re_1,downx,downy,white_flage,chose_location,white_list,black_list,old_list)
        else :
            white_list,black_list,white_flage,chose_location,old_list,be_chose = judge(be_chose,screen,board,white_list,black_list,downx,downy,white_flage,chose_location,old_list)
        #print('chose_location',chose_location)
        #print('be_chose',be_chose)
        mos_flage = False   #鼠标点击后进行以上处理
        board = [[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]] #空白化棋盘，以待刷新
        for i in white_list :   #从白棋列表中清楚被杀掉的棋子
            if not i.live :
                white_list.remove(i)
        for i in white_list :        #刷新棋盘
            board[i.posy][i.posx] = i
        for i in black_list :
            board[i.posy][i.posx] = i
        for i in white_list :        #显示黑白棋子，重新搜索周围情况
            screen.blit(whitechess,i.rec)
            i.chess_search(board)
        for i in black_list :
            screen.blit(blackchess,i.rec)
            i.chess_search(board,white_list)
        if white_flage :            #重新绘制黑白手棋标志
            screen.blit(white_1,[72,225])
            screen.blit(black,[72,100])
            
        else :
            screen.blit(white,[72,225])
            screen.blit(black_1,[72,100])
        if not be_chose[0] == 10 :   #画圈
            pygame.draw.circle(screen,[255,0,0],[be_chose[0]*150+350,be_chose[1]*150+40],75,2)
    
       
        
    pygame.display.update()
    end = judge_end(white_list,black_list)  #终局判定
    
    if end :
        if end == 1 :      #如果终局，根据输赢情况，打印文字
            screen.blit(b_win,[500,340])
            record_file = open('chess_record.txt','a')
            
            record_file.write('black win'+'\n')
            record_file.close()
            pygame.display.update()
            while True :    #等待退出
                for event in pygame.event.get() :
                    if event.type == QUIT :
                        pygame.quit()
                        sys.exit()
        if end == 2 :
            screen.blit(w_win,[500,340])
            record_file = open('chess_record.txt','a')
            
            record_file.write('white win'+'\n')
            record_file.close()
            pygame.display.update()
            while True :
                for event in pygame.event.get() :
                    if event.type == QUIT :
                        pygame.quit()
                        sys.exit()
        
#失败，陷入了死循环










    
